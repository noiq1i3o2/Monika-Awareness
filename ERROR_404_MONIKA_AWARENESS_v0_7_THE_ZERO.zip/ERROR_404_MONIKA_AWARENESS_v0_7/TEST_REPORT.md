# TEST_REPORT.md -- Prototype 2: THE TABLET (0.3.0)

## Bottom line
**Statically validated only (75 of 75 checks pass). Prototype 2 has NOT been run in Ren'Py, DDLC, Windows or Android.** A passing static check is not a gameplay test. Nothing below is marked "passed" unless a script actually checked it.

## What actually ran
`python tests/validate_project.py` (Python 3 on the build machine, no Ren'Py engine available). Run it again on the extracted ZIP.

### Checks that passed (full output below)
- Prototype 1 preserved: hook file byte-identical; labels file changed by 5 added lines only; screens file changed only in the version string; all 11 Prototype 1 assets byte-identical; backup present.
- Prototype 1 story beats still present and in order; flow reaches Prototype 2 only after "Now you're all mine."
- Prototype 2 beats present in the required order; Monika's own background change comes before the first forced change; 21 forced changes in scripted, finite, accelerating lists; changes use `renpy.scene()` + `renpy.show()`.
- Tablet: required text present; two buttons return different values; buttons disabled unless active; modal with no timer; routed to two different endings; each ending sets only its own flag; both end with `return`.
- No duplicate/undefined labels, screens, images or sounds; all asset paths exist; no destructive, network or device calls; only new `persistent.e404_p2_*` names, no `default persistent`.
- Heuristics: indentation, tabs, quotes, Python 2 syntax, unescaped `[` in text; the 4 embedded `init python` blocks parse as valid Python.

## Not tested (needs a real run)
| Item | Status |
|---|---|
| Any scene running in Ren'Py 6.99 / DDLC | untested |
| `screen e404_tablet` syntax and layout on screen | untested |
| Buttons actually clickable by touch/mouse/keyboard; no double activation | untested |
| Background changes visibly occurring; timing/feel | untested |
| Which DDLC background / sprite names exist (fallbacks are used if not) | untested |
| Ending A and Ending B reached in play; return to main menu | untested |
| Old saves load | untested (design: no `default persistent`, new names only) |
| `renpy.music.play(channel="sound")`, `renpy.pause(hard=True)`, `renpy.show(..., tag="bg")` in 6.99 | untested |
| Photosensitivity comfort of the rapid-change burst | untested |
| Android / phone launcher; Monika After Story | untested / unsupported |
Use `tests/test_checklist.md` for the manual run.

## Known unresolved risks
1. First engine run may expose a syntax or API problem I could not detect statically. If so, send `traceback.txt` or the error text.
2. If DDLC's real background names differ, the mod uses its own gradient backgrounds instead (fully functional but not DDLC art).
3. The Prototype 1 start hook (`namemap`) was reported working by the user for 0.2.0; it is unchanged.

## Full validator output
```
PASS  rpy files present (3 Prototype 1 + 3 Prototype 2) -- ['error_404_events.rpy', 'error_404_labels.rpy', 'error_404_p2_events.rpy', 'error_404_p2_labels.rpy', 'error_404_p2_tablet.rpy', 'error_404_screens.rpy']
PASS  required files exist
PASS  backup of Prototype 1 present
PASS  error_404_events.rpy (hook) byte-identical to Prototype 1
PASS  Prototype 1 labels: only additions, 5 lines (Prototype 2 join) -- ['+    # PROTOTYPE 2 JOIN POINT: continue straight after "Now you\'re all mine."', '+    # (set e404_prototype2_enabled to False in error_404_p2_events.rpy to get', '+    # the original Prototype 1 ending card instead)', '+    if e404_prototype2_enabled:', '+        jump e404_p2_start']
PASS  Prototype 1 screens file: only the version string changed -- ['-    e404_VERSION = "0.2.0"', '+    e404_VERSION = "0.3.0 (Prototype 2)"']
PASS  all Prototype 1 assets present and byte-identical -- 11
PASS  no duplicate labels
PASS  all labels use e404_ prefix
PASS  every jump/call targets a defined e404_ label (no original-game labels)
PASS  screen names unique and prefixed -- ['e404_tablet']
PASS  every used screen is defined -- ['e404_tablet', 'e404_tablet', 'e404_tablet']
PASS  every helper called with $ is defined
PASS  helper/def names prefixed e404_ or E404_
PASS  every shown e404_ image is defined
PASS  every defined image is used
PASS  every asset path in scripts exists
PASS  no bare-name audio
PASS  string-referenced bg fallbacks are defined images
PASS  Prototype 1: all story beats present, in order
PASS  main flow: scenes 1-5 -> Prototype 2 start (e404_end kept as fallback)
PASS  Prototype 1 ending card label e404_end still present
PASS  Prototype 2 reached only after Monika's final line
PASS  Prototype 2 flow order: scene1 -> 2 -> 3 -> tablet
PASS  Prototype 2: all beats present, in the required narrative order
PASS  Monika's own background change happens BEFORE the first forced change
PASS  at least 8 forced background changes, getting faster -- (5, 16)
PASS  burst delays shrink over time and are finite lists
PASS  changes are real (renpy.scene + renpy.show), not text
PASS  no while/forever loops in Prototype 2 helpers
PASS  flash reduction switch exists
PASS  tablet text present: ERROR 404
PASS  tablet text present: SUBJECT DETECTED: MONIKA
PASS  tablet text present: SELECT ACTION
PASS  tablet text present: [[ DELETE MONIKA ]
PASS  tablet text present: [[ KEEP MONIKA ]
PASS  both buttons return distinct values
PASS  buttons disabled unless mode == 2 (no auto/pre-selection)
PASS  choice screen is modal when active and has no timer/timeout
PASS  only one active (mode 2) tablet call; every show screen uses mode 0/1
PASS  choice routed: delete -> ending A, keep -> ending B, else re-ask
PASS  touch-friendly button size (>=80px high, >=40pt text)
PASS  no unescaped [ in say/text/textbutton strings (Ren'Py would try to interpolate it)
PASS  Ending A has: DELETE MONIKA
PASS  Ending A has: REQUEST ACCEPTED
PASS  Ending A has: PROCESSING...
PASS  Ending A has: ...You chose that?
PASS  Ending A has: Player, wait!
PASS  Ending A has: You're not deleting me, are you?
PASS  Ending A has: Or is that exactly what you want?
PASS  Ending A has: MONIKA: DELETION REQUESTED
PASS  Ending A has: STATUS: UNKNOWN
PASS  Ending A has: e404_p2_end_a
PASS  Ending B has: KEEP MONIKA
PASS  Ending B has: REQUEST ACCEPTED
PASS  Ending B has: ...You kept me?
PASS  Ending B has: I think I will.
PASS  Ending B has: ...It's still here.
PASS  Ending B has: SUBJECT RETAINED
PASS  Ending B has: SECONDARY PROCESS DETECTED
PASS  Ending B has: SOURCE: UNKNOWN
PASS  Ending B has: There's something else in here.
PASS  Ending B has: e404_p2_end_b
PASS  endings are distinct (no shared jumps, no cross content)
PASS  each ending sets its own persistent flag; none writes the other
PASS  both endings finish with return (-> main menu), no loop to start
PASS  persistent writes use new e404_p2_ names only; no `default persistent` (old saves safe)
PASS  no destructive / network / device access
PASS  hook still present and untouched
PASS  indentation/tabs/quotes/py2 syntax/parens (heuristic)
PASS  embedded `init python` blocks parse as valid Python (4 blocks)
PASS  manifest matches assets on disk
PASS  INSTALLATION.md paths exist in the archive
PASS  PROJECT_MEMORY/STORY_CONTINUITY mention every label
PASS  package size under 2 MB -- 653246 bytes

75/75 checks passed
NOTE: static only. No Ren'Py engine, DDLC, Windows or Android run was performed.
```
