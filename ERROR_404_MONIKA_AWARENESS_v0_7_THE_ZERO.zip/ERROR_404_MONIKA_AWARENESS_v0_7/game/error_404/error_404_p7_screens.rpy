## ERROR 404: MONIKA AWARENESS -- v0.7 screens: the error box, the "are you sure" box,
## the device choice and the walk. Python 2 / Ren'Py 6.99 compatible screen syntax.

image e404_p7_void = Solid("#050308")

transform e404_p7_stutter:
    xoffset 0
    alpha 1.0
    pause 0.9
    xoffset 14
    alpha 0.55
    pause 0.05
    xoffset -10
    alpha 1.0
    pause 0.04
    xoffset 0
    pause 0.7
    xoffset -24
    alpha 0.4
    pause 0.06
    xoffset 0
    alpha 1.0
    pause 1.1
    repeat

transform e404_p7_ghost:
    xoffset 20
    yoffset -4
    alpha 0.3
    pause 1.2
    xoffset -16
    yoffset 3
    alpha 0.22
    pause 0.08
    xoffset 26
    alpha 0.34
    pause 0.9
    repeat

transform e404_p7_err_flicker:
    alpha 1.0
    pause 2.6
    alpha 0.55
    pause 0.05
    alpha 1.0
    pause 0.12
    alpha 0.7
    pause 0.04
    alpha 1.0
    repeat

## The first thing the player sees after the save reads 0 KB.
screen e404_p7_error():
    modal True
    zorder 400
    add Solid("#050308")
    add "e404_p3_vignette"
    fixed:
        xalign 0.5
        yalign 0.5
        xysize (860, 420)
        add Solid("#2a0a10") xysize (860, 420)
        add Solid("#0b0408") xpos 3 ypos 3 xysize (854, 414)
        add Solid("#a8142b") xpos 3 ypos 3 xysize (854, 54)
        text "ERROR  0xE404" size 30 color "#ffffff" xpos 24 ypos 12
        text "save_01.sav  :  0 KB" size 26 color "#ff5a6e" xpos 40 ypos 92 at e404_p7_err_flicker
        text "The save file is empty." size 28 color "#e9e9f2" xpos 40 ypos 150
        text "Something took everything that was inside it." size 28 color "#e9e9f2" xpos 40 ypos 190
        text "The game can no longer tell who is playing whom." size 24 color "#8a8a98" xpos 40 ypos 244
        hbox:
            xalign 0.5
            ypos 330
            spacing 70
            textbutton "Go Back":
                action Return("back")
                text_size 38
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5a6e"
            textbutton "Continue Anyway":
                action Return("go")
                text_size 38
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5a6e"

screen e404_p7_confirm():
    modal True
    zorder 410
    add Solid("#050308")
    add "e404_p3_vignette"
    fixed:
        xalign 0.5
        yalign 0.5
        xysize (860, 360)
        add Solid("#2a0a10") xysize (860, 360)
        add Solid("#0b0408") xpos 3 ypos 3 xysize (854, 354)
        add Solid("#a8142b") xpos 3 ypos 3 xysize (854, 54)
        text "ARE YOU SURE?" size 30 color "#ffffff" xpos 24 ypos 12
        text "Every piece of data will be deleted," size 32 color "#e9e9f2" xpos 40 ypos 110
        text "including backups." size 32 color "#ff5a6e" xpos 40 ypos 156
        hbox:
            xalign 0.5
            ypos 260
            spacing 120
            textbutton "Yes":
                action Return("yes")
                text_size 40
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5a6e"
            textbutton "No":
                action Return("no")
                text_size 40
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5a6e"

screen e404_p7_device():
    modal True
    zorder 400
    add Solid("#050308") alpha 0.82
    add "e404_p3_vignette"
    fixed:
        xalign 0.5
        yalign 0.5
        xysize (900, 400)
        add Solid("#1a1c2a") xysize (900, 400)
        add Solid("#07080d") xpos 3 ypos 3 xysize (894, 394)
        text "Select the device you are using." size 34 color "#e9e9f2" xalign 0.5 ypos 40
        text "Are you using mobile or PC?" size 30 color "#9aa0c0" xalign 0.5 ypos 92
        text "WARNING" size 24 color "#ff5a6e" xalign 0.5 ypos 172
        text "If you choose the wrong device, it may completely alter\nthe gameplay and the game window." size 24 color "#ff5a6e" xalign 0.5 ypos 206 text_align 0.5
        hbox:
            xalign 0.5
            ypos 300
            spacing 150
            textbutton "Mobile":
                action Return("mobile")
                text_size 42
                text_idle_color "#e9e9f2"
                text_hover_color "#00e6ff"
            textbutton "PC":
                action Return("pc")
                text_size 42
                text_idle_color "#e9e9f2"
                text_hover_color "#00e6ff"

screen e404_p7_walk():
    modal True
    zorder 300
    add Solid("#000000")
    add e404_p7_get_walk()
    timer 0.25 repeat True action E404Poll()
