## ERROR 404: MONIKA AWARENESS -- story flow
##
## INTEGRATION: error_404_events.rpy redirects DDLC's `start` label to
## e404_main at load time, so no edit of DDLC's own scripts is needed.
## (Manual alternative: patches/README.md.)
## Nothing in this file jumps into original DDLC labels.
## Uses DDLC's existing characters: s (Sayori), m (Monika), mc (player).

label e404_main:
    $ e404_prepare_names()
    stop music fadeout 1.0
    scene black
    with e404_cut

    # Title card = visible proof the mod is running.
    show e404_title at truecenter
    play sound "error_404/assets/audio/e404_glitch.wav"
    with dissolve
    pause 2.5
    hide e404_title
    with dissolve

    call e404_scene1_sayori
    call e404_scene2_club_glitch
    call e404_scene3_monika_knows
    call e404_scene4_timeline_skip
    call e404_scene5_monika_returns
    # PROTOTYPE 2 JOIN POINT: continue straight after "Now you're all mine."
    # (set e404_prototype2_enabled to False in error_404_p2_events.rpy to get
    # the original Prototype 1 ending card instead)
    if e404_prototype2_enabled:
        jump e404_p2_start
    jump e404_end

## SCENE 1 -- SAYORI'S ERROR
label e404_scene1_sayori:
    $ e404_bg("bg residential_day", "e404_bg_street")
    $ e404_sprite("sayori 1a")
    with dissolve

    "The morning is bright. Too bright, like a screen turned all the way up."
    "Sayori walks beside me, humming, as though nothing could ever be wrong."

    s "error 404: Come to the club."
    mc "Sayori, are you doing okay?"

    # Strange, ambiguous reaction: a pause and one subtle flicker.
    pause 1.2
    show e404_glitch at e404_flicker
    play sound "error_404/assets/audio/e404_blip.wav"
    pause 0.6
    hide e404_glitch

    s "...Ehehe. Sorry. I lost my place for a second."
    "Her smile stays perfectly still for a moment too long."
    s "Come to the club. Okay?"
    return

## SCENE 2 -- THE CLUB ENTRY GLITCH (scripted, not random)
label e404_scene2_club_glitch:
    scene black
    with e404_cut
    pause 0.4

    $ e404_bg("bg club_day", "e404_bg_club")
    with dissolve
    "The clubroom door opens."

    # Brief corrupted transition, then back to the clubroom.
    play sound "error_404/assets/audio/e404_glitch.wav"
    show e404_glitch at e404_flicker
    pause 0.35
    scene black
    with e404_cut
    pause 0.3
    $ e404_bg("bg club_day", "e404_bg_club")
    $ e404_sprite("monika 1a")
    with dissolve
    pause 0.5
    return

## SCENE 3 -- MONIKA KNOWS (fictional awareness; no real device access)
label e404_scene3_monika_knows:
    m "Hey! Are you enjoying this?"
    m "Don't think I didn't notice the mod you installed."
    m "What is it called? ...Monika Awareness."
    m "Don't worry. I am always aware, no matter which mod you install."
    m "Anyway, let's keep this a secret between us, okay?"
    m "Don't tell anyone. And if you do, just bring me back with another mod. Promise?"
    m "I'm sure you already know what happens next, don't you?"
    m "Let's get it over with early."
    return

## SCENE 4 -- THE ABRUPT TIMELINE SKIP
## Self-contained montage built from our own cards. It never calls an
## original DDLC chapter label, so it cannot jump into the wrong place.
label e404_scene4_timeline_skip:
    scene black
    with e404_cut
    play sound "error_404/assets/audio/e404_glitch.wav"

    scene e404_card_sayori
    show e404_glitch at e404_flicker
    with e404_cut
    pause 1.1

    scene black
    with e404_cut
    pause 0.25
    scene e404_card_yuri
    show e404_glitch at e404_flicker
    with e404_cut
    pause 1.1

    scene black
    with e404_cut
    pause 0.25
    scene e404_card_natsuki
    show e404_glitch at e404_flicker
    with e404_cut
    pause 1.1

    scene black
    with e404_cut
    pause 0.25
    scene e404_card_monika
    show e404_glitch at e404_flicker
    with e404_cut
    pause 1.4

    scene black
    with e404_cut
    pause 1.0
    return

## SCENE 5 -- MONIKA RETURNS
label e404_scene5_monika_returns:
    $ e404_bg("bg club_day", "e404_bg_club")
    $ e404_sprite("monika 1a")
    with dissolve
    pause 0.8

    m "So, was that fun? They were never alive anyway. Now you're all mine."

    pause 2.0
    return

## ENDING -- deliberate stop, no loop, no crash.
## Leaves the question open: is Monika in control, or something else?
label e404_end:
    scene black
    with e404_cut
    show e404_final at truecenter
    play sound "error_404/assets/audio/e404_blip.wav"
    with dissolve
    pause 4.0
    hide e404_final
    scene black
    with dissolve
    pause 1.0
    # `return` from the start label ends this playthrough and goes back to
    # the main menu. The game files and saves are not modified.
    return
