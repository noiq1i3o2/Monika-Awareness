## ERROR 404: MONIKA AWARENESS -- v0.7: THE WALK HOME
## Helpers, the reset routine and the walkable street (custom displayable).
## Python 2 compatible (DDLC = Ren'Py 6.99). Everything is wrapped so a missing
## image / sound / engine feature degrades quietly instead of crashing.

## True = Load Game opens v0.7 at once (testing). False = only after the save reads 0 KB.
define e404_p7_test_start = False
## True = picking the wrong device (mobile vs PC) inverts the controls and renames the window.
define e404_p7_punish_wrong_device = True
## Seconds before the figure starts walking toward you on its own.
define e404_p7_creep_after = 150
## True = fewer flashes / no static during the walk (also set by e404_p2_reduce_flashing).
define e404_p7_calm = False

default e404_device = None
default e404_p7_invert = False

## One short line per character, from the original game, in the order they appear.
## EDIT THESE FREELY. They were written from memory, so check them against your copy of DDLC.
define e404_p7_line_sayori = "Ehehe~ I overslept again!"
define e404_p7_line_yuri = "I-I'm sorry... I get carried away with books."
define e404_p7_line_natsuki = "I-It's not like I wanted you to eat them or anything!"

init -2 python:
    try:
        import pygame_sdl2 as pygame
    except Exception:
        import pygame

init -1 python:
    import math
    import random

    class E404P7Hold(object):
        """Class attribute = lives outside the save file (a Displayable must not be pickled)."""
        walk = None

    def e404_p7_get_walk():
        return E404P7Hold.walk

    ## ---------------- reset ("Go Back" -> "Yes") ----------------
    def e404_p7_reset_game():
        """Resets THIS MOD's flags only. No DDLC save, backup or file is touched."""
        for n in ("e404_p2_started", "e404_p2_ending", "e404_p2_seen_a", "e404_p2_seen_b",
                  "e404_p3_visits", "e404_p3_done", "e404_p7_seen", "e404_p7_finished"):
            try:
                setattr(persistent, n, None)
            except Exception:
                pass
        try:
            renpy.save_persistent()
        except Exception:
            pass

    ## ---------------- device choice ----------------
    def e404_p7_apply_device(choice):
        """Remember the choice. A wrong choice (checked against the real platform) is punished."""
        st = renpy.store
        st.e404_device = choice
        st.e404_p7_invert = False
        actual = None
        try:
            actual = "mobile" if bool(getattr(renpy, "mobile", False)) else "pc"
        except Exception:
            actual = None
        wrong = (actual is not None and actual != choice)
        if wrong and st.e404_p7_punish_wrong_device:
            st.e404_p7_invert = True
            try:
                renpy.config.window_title = u"ERROR 404 :: WRONG DEVICE"
                renpy.display.interface.set_window_caption(force=True)
            except Exception:
                pass
        print("[E404] device chosen=" + str(choice) + " detected=" + str(actual) + " wrong=" + str(wrong))
        return wrong

    def e404_p7_restore_title():
        try:
            renpy.config.window_title = u"Doki Doki Literature Club"
            renpy.display.interface.set_window_caption(force=True)
        except Exception:
            pass

    ## ---------------- glitched sprites ----------------
    def e404_p7_show_glitched(sprite, card):
        """Show a DDLC sprite twice (a ghost copy) with a stutter; fall back to our own card."""
        try:
            renpy.scene()
            renpy.show("e404_p7_void")
            if e404_has(sprite):
                pos = getattr(renpy.store, "t11", None)
                base = [pos] if pos is not None else []
                renpy.show(sprite, at_list=base + [renpy.store.e404_p7_stutter], tag="e404_g1")
                renpy.show(sprite, at_list=base + [renpy.store.e404_p7_ghost], tag="e404_g2", zorder=1)
            else:
                renpy.show(card, at_list=[renpy.store.e404_p7_stutter])
            renpy.show("e404_glitch", at_list=[renpy.store.e404_flicker], zorder=11)
            e404_p3_sfx("e404_glitch.wav")
        except Exception as e:
            print("[E404] glitched sprite failed: " + repr(e))

    ## ---------------- the walk ----------------
    class E404Walk(renpy.Displayable):
        W = 2400.0          # the world wraps: walk far enough and you come back
        H = 1800.0
        SPEED = 175.0
        WHISPERS = [
            "There is nobody here to run up to you.",
            "Keep moving.",
            "This street was never meant to be walked.",
            "The houses are the same houses.",
            "Sayori should be here by now.",
            "Do not stop walking.",
            "It is learning how you move.",
            "You know the way home. The street does not.",
        ]

        def __init__(self, mobile=False, invert=False, calm=False, lite=False, **kw):
            renpy.Displayable.__init__(self, **kw)
            self.mobile = mobile
            self.invert = invert
            self.calm = calm
            self.lite = lite
            self.px = 300.0
            self.py = 905.0
            self.keys = set()
            self.joy_on = False
            self.joy_o = (0, 0)
            self.joy_p = (0, 0)
            self.last = None
            self.t0 = None
            self.walked = 0.0
            self.step_phase = 0.0
            self.step_clock = 0.0
            self.still = 0.0
            self.moving = False
            self.done = False
            self.final_t = None
            self.encounters = 0
            self.fig_on = False
            self.fig_x = 0.0
            self.fig_y = 0.0
            self.fig_next = 450.0       # walked-distance at which it may appear
            self.fig_gone_until = 0.0
            self.flash_until = 0.0
            self.whisper_i = 0
            self.whisper_next = 9.0
            self.whisper_show_until = 0.0
            self.whisper_text = None
            self.hb_clock = 0.0
            self.solids = {}
            self.texts = {}
            self.rng = random.Random(404)
            self.km = {pygame.K_w: "u", pygame.K_UP: "u", pygame.K_s: "d", pygame.K_DOWN: "d",
                       pygame.K_a: "l", pygame.K_LEFT: "l", pygame.K_d: "r", pygame.K_RIGHT: "r"}
            self.glow = renpy.displayable("error_404/assets/p7/e404_p7_glow.png")
            self.dark = renpy.displayable("error_404/assets/p7/e404_p7_dark.png")
            self.joy_base = renpy.displayable("error_404/assets/p7/e404_p7_joy_base.png")
            self.joy_knob = renpy.displayable("error_404/assets/p7/e404_p7_joy_knob.png")
            self.static = renpy.displayable("error_404/assets/ui/e404_p3_static.png")
            self.build_world()

        ## ---- world ----
        def build_world(self):
            r = random.Random(1999)
            self.houses = []     # (x, y, w, h, lit)
            self.trees = []      # (x, y)
            self.lamps = []      # (x, y)
            ROAD_Y = 900.0
            # north side and south side of the long road
            i = 0
            x = 60.0
            while x < self.W - 260:
                if not (1060 < x < 1340):          # leave the crossing free
                    w = 190 + r.randint(0, 70)
                    h = 140 + r.randint(0, 60)
                    self.houses.append((x, ROAD_Y - 120 - h, w, h, r.random() < 0.18))
                    h2 = 130 + r.randint(0, 60)
                    self.houses.append((x + r.randint(0, 40), ROAD_Y + 120, w - 20, h2, r.random() < 0.18))
                    x += w + 110 + r.randint(0, 60)
                else:
                    x += 140
                i += 1
            # lamps along the road, alternating sides
            lx = 140.0
            n = 0
            while lx < self.W:
                self.lamps.append((lx, ROAD_Y - 112 if n % 2 == 0 else ROAD_Y + 106))
                lx += 330
                n += 1
            # trees in the open ground (away from the roads and houses)
            tries = 0
            while len(self.trees) < 46 and tries < 900:
                tries += 1
                tx = r.uniform(30, self.W - 30)
                ty = r.uniform(30, self.H - 30)
                if abs(ty - ROAD_Y) < 330 or abs(tx - 1200.0) < 120:
                    continue
                self.trees.append((tx, ty))
            # a few trees right by the road for atmosphere
            for k in range(8):
                self.trees.append((r.uniform(40, self.W - 40), ROAD_Y + (-250 if k % 2 == 0 else 250) + r.uniform(-20, 20)))
            self.obst = []
            for (hx, hy, hw, hh, lit) in self.houses:
                self.obst.append((hx, hy, hw, hh))
            for (tx, ty) in self.trees:
                self.obst.append((tx, ty, 14, 22))
            for (lx, ly) in self.lamps:
                self.obst.append((lx, ly + 74, 6, 16))

        def wd(self, a, b, size):
            d = (a - b) % size
            if d > size / 2.0:
                d -= size
            return d

        def blocked(self, nx, ny):
            for (ox, oy, ow, oh) in self.obst:
                rl = self.wd(ox, nx, self.W)
                if rl >= 10 or rl + ow <= -10:
                    continue
                rt = self.wd(oy, ny, self.H)
                if rt < 6 and rt + oh > -6:
                    return True
            return False

        ## ---- drawing helpers ----
        def solid(self, color):
            s = self.solids.get(color)
            if s is None:
                s = Solid(color)
                self.solids[color] = s
            return s

        def text(self, msg, size, color):
            k = (msg, size, color)
            t = self.texts.get(k)
            if t is None:
                t = Text(msg, size=size, color=color, outlines=[(2, "#000000", 0, 0)])
                self.texts[k] = t
            return t

        def rect(self, rv, x, y, w, h, color, width, height, st, at):
            if x > width or y > height or x + w < 0 or y + h < 0:
                return
            w = max(1, int(w))
            h = max(1, int(h))
            r = renpy.render(self.solid(color), w, h, st, at)
            rv.blit(r, (int(x), int(y)))

        def img(self, rv, d, x, y, width, height, st, at):
            r = renpy.render(d, width, height, st, at)
            rv.blit(r, (int(x), int(y)))

        ## ---- input ----
        def event(self, ev, x, y, st):
            try:
                t = ev.type
                if t == pygame.KEYDOWN:
                    k = self.km.get(ev.key)
                    if k:
                        self.keys.add(k)
                elif t == pygame.KEYUP:
                    k = self.km.get(ev.key)
                    if k:
                        self.keys.discard(k)
                elif t == pygame.MOUSEBUTTONDOWN:
                    if getattr(ev, "button", 1) == 1:
                        self.joy_on = True
                        self.joy_o = (x, y)
                        self.joy_p = (x, y)
                elif t == pygame.MOUSEMOTION:
                    if self.joy_on:
                        self.joy_p = (x, y)
                elif t == pygame.MOUSEBUTTONUP:
                    if getattr(ev, "button", 1) == 1:
                        self.joy_on = False
            except Exception:
                pass
            if self.done:
                return "end"
            return None

        def joy_vec(self):
            if not self.joy_on:
                return (0.0, 0.0)
            dx = self.joy_p[0] - self.joy_o[0]
            dy = self.joy_p[1] - self.joy_o[1]
            m = math.sqrt(dx * dx + dy * dy)
            if m < 12:
                return (0.0, 0.0)
            k = min(1.0, m / 90.0)
            return (dx / m * k, dy / m * k)

        ## ---- simulation ----
        def sfx(self, name, vol=None, channel="sound"):
            try:
                renpy.music.play("error_404/assets/audio/" + name, channel=channel)
                if vol is not None:
                    renpy.music.set_volume(vol, channel=channel)
            except Exception:
                pass

        def update(self, dt, st):
            locked = self.final_t is not None
            vx = vy = 0.0
            if not locked:
                if "l" in self.keys: vx -= 1.0
                if "r" in self.keys: vx += 1.0
                if "u" in self.keys: vy -= 1.0
                if "d" in self.keys: vy += 1.0
                jx, jy = self.joy_vec()
                vx += jx
                vy += jy
            m = math.sqrt(vx * vx + vy * vy)
            if m > 1.0:
                vx /= m
                vy /= m
                m = 1.0
            if self.invert:
                vx = -vx
                vy = -vy
            self.moving = m > 0.05
            if self.moving:
                dx = vx * self.SPEED * dt
                dy = vy * self.SPEED * dt
                nx = (self.px + dx) % self.W
                if not self.blocked(nx, self.py):
                    self.px = nx
                else:
                    dx = 0.0
                ny = (self.py + dy) % self.H
                if not self.blocked(self.px, ny):
                    self.py = ny
                else:
                    dy = 0.0
                self.walked += math.sqrt(dx * dx + dy * dy)
                self.step_phase += dt * 9.0
                self.step_clock += dt
                if self.step_clock > 0.42:
                    self.step_clock = 0.0
                    self.sfx("e404_p2_tick.wav", 0.18, "e404_step")
                self.still = 0.0
            else:
                self.still += dt

            # ---- the figure ----
            fd = None
            if self.fig_on:
                fdx = self.wd(self.fig_x, self.px, self.W)
                fdy = self.wd(self.fig_y, self.py, self.H)
                fd = math.sqrt(fdx * fdx + fdy * fdy)
            if not self.fig_on and self.final_t is None and self.walked >= self.fig_next and st >= self.fig_gone_until:
                ang = self.rng.uniform(0, 6.2831)
                if self.moving and self.rng.random() < 0.6:
                    ang = math.atan2(vy, vx) + self.rng.uniform(-0.5, 0.5)
                self.fig_x = (self.px + math.cos(ang) * 330.0) % self.W
                self.fig_y = (self.py + math.sin(ang) * 330.0) % self.H
                self.fig_on = True
                fd = 330.0
                self.sfx("e404_p3_whisper.wav", 0.5, "e404_step")
            elif self.fig_on and fd is not None:
                # it only ever moves while you are not watching it move: i.e. when you stand still
                creep = 0.0
                if self.still > 2.2:
                    creep = 62.0
                elif st > self.t0 + float(renpy.store.e404_p7_creep_after):
                    creep = 20.0
                if creep > 0.0 and fd > 1.0:
                    k = min(fd, creep * dt) / fd
                    self.fig_x = (self.fig_x - self.wd(self.fig_x, self.px, self.W) * k) % self.W
                    self.fig_y = (self.fig_y - self.wd(self.fig_y, self.py, self.H) * k) % self.H
                    fd = fd * (1.0 - k)
                if self.final_t is None:
                    if fd < 58.0 or (fd < 100.0 and self.encounters >= 2):
                        self.final_t = st
                        self.sfx("e404_glitch.wav", 0.8, "sound")
                    elif fd < 100.0 and self.moving:
                        self.encounters += 1
                        self.fig_on = False
                        self.fig_next = self.walked + 420.0
                        self.fig_gone_until = st + 7.0
                        self.flash_until = st + 0.35
                        self.sfx("e404_glitch.wav", 0.7, "sound")
                        self.whisper_text = "It was there a moment ago."
                        self.whisper_show_until = st + 4.0
            self.fd = fd

            # ---- heartbeat follows the figure ----
            self.hb_clock += dt
            if self.hb_clock > 0.25:
                self.hb_clock = 0.0
                try:
                    if fd is not None and not self.lite:
                        if not renpy.music.is_playing(channel="e404_hb"):
                            renpy.music.play("error_404/assets/audio/e404_p3_heartbeat.wav", channel="e404_hb", loop=True)
                        renpy.music.set_volume(max(0.0, min(1.0, 1.15 - fd / 340.0)), channel="e404_hb")
                    elif renpy.music.is_playing(channel="e404_hb"):
                        renpy.music.stop(channel="e404_hb", fadeout=1.0)
                except Exception:
                    pass

            # ---- whispers ----
            if st - self.t0 > self.whisper_next and self.final_t is None:
                self.whisper_text = self.WHISPERS[self.whisper_i % len(self.WHISPERS)]
                self.whisper_i += 1
                self.whisper_show_until = st + 4.5
                self.whisper_next = (st - self.t0) + 15.0 + self.rng.uniform(0, 8)

            # ---- ending ----
            if self.final_t is not None and st - self.final_t > 3.2:
                self.done = True

        ## ---- render ----
        def render(self, width, height, st, at):
            if self.t0 is None:
                self.t0 = st
                self.last = st
            dt = st - self.last
            self.last = st
            if dt < 0 or dt > 0.1:
                dt = 0.1 if dt > 0.1 else 0.0
            try:
                self.update(dt, st)
            except Exception as e:
                print("[E404] walk update failed: " + repr(e))
            rv = renpy.Render(width, height)
            cx = width / 2.0
            cy = height / 2.0
            fd = getattr(self, "fd", None)

            def sx(wx):
                return cx + self.wd(wx, self.px, self.W)
            def sy(wy):
                return cy + self.wd(wy, self.py, self.H)

            shake = 0
            if fd is not None and fd < 200 and not self.calm:
                shake = int((200 - fd) / 40)
            ox = self.rng.randint(-shake, shake) if shake else 0
            oy = self.rng.randint(-shake, shake) if shake else 0
            cx += ox
            cy += oy

            # ground, roads
            self.rect(rv, 0, 0, width, height, "#0b120e", width, height, st, at)
            ry = sy(900.0)
            self.rect(rv, 0, ry - 78, width, 156, "#14151c", width, height, st, at)
            self.rect(rv, 0, ry - 100, width, 22, "#1b1c26", width, height, st, at)
            self.rect(rv, 0, ry + 78, width, 22, "#1b1c26", width, height, st, at)
            k = (cx - self.px) % 120.0 - 120.0
            while k < width + 120:
                self.rect(rv, k, ry - 3, 56, 6, "#2c2d3a", width, height, st, at)
                k += 120.0
            vx_ = sx(1200.0)
            self.rect(rv, vx_ - 66, 0, 132, height, "#14151c", width, height, st, at)
            self.rect(rv, vx_ - 88, 0, 22, height, "#1b1c26", width, height, st, at)
            self.rect(rv, vx_ + 66, 0, 22, height, "#1b1c26", width, height, st, at)
            self.rect(rv, vx_ - 66, ry - 78, 132, 156, "#14151c", width, height, st, at)

            # houses
            tnow = st
            for idx, (hx, hy, hw, hh, lit) in enumerate(self.houses):
                x = sx(hx)
                y = sy(hy)
                if x > width + 60 or y > height + 60 or x + hw < -60 or y + hh < -60:
                    continue
                self.rect(rv, x - 8, y - 26, hw + 16, 28, "#0d0e14", width, height, st, at)
                self.rect(rv, x, y, hw, hh, "#1a1c26" if idx % 2 == 0 else "#20202b", width, height, st, at)
                self.rect(rv, x + hw * 0.45, y + hh - 52, 34, 52, "#07070b", width, height, st, at)
                wcol = "#e8c46a" if (lit and int(tnow * 1.3 + idx) % 11 != 0) else "#07080d"
                self.rect(rv, x + 22, y + 36, 38, 34, wcol, width, height, st, at)
                self.rect(rv, x + hw - 60, y + 36, 38, 34, "#07080d", width, height, st, at)

            # trees
            for (tx, ty) in self.trees:
                x = sx(tx)
                y = sy(ty)
                if x > width + 50 or y > height + 80 or x < -50 or y < -80:
                    continue
                self.rect(rv, x, y, 14, 22, "#17120d", width, height, st, at)
                self.rect(rv, x - 22, y - 30, 58, 26, "#0d2218", width, height, st, at)
                self.rect(rv, x - 12, y - 52, 38, 26, "#10301f", width, height, st, at)
                self.rect(rv, x - 2, y - 66, 18, 16, "#0d2218", width, height, st, at)

            # lamps (poles; the glow comes after the darkness)
            lit_lamps = []
            for n, (lx, ly) in enumerate(self.lamps):
                x = sx(lx)
                y = sy(ly)
                if x > width + 150 or y > height + 150 or x < -150 or y < -150:
                    continue
                self.rect(rv, x, y, 6, 90, "#0a0a10", width, height, st, at)
                self.rect(rv, x - 8, y - 6, 22, 9, "#0a0a10", width, height, st, at)
                dead_at = 260.0 + n * 330.0
                alive = self.walked < dead_at
                if alive:
                    flick = 1.0
                    if int(st * 9 + n * 5) % 23 == 0:
                        flick = 0.25
                    # the nearer to its death, the more it stutters
                    if dead_at - self.walked < 500 and int(st * 14 + n) % 5 == 0:
                        flick *= 0.3
                    lit_lamps.append((x - 118, y - 118, flick))

            # footprints / player
            bob = int(math.sin(self.step_phase) * 2) if self.moving else 0
            px_ = cx
            py_ = cy
            self.rect(rv, px_ - 11, py_ + 14, 22, 6, "#000000bb", width, height, st, at)
            leg = int(math.sin(self.step_phase) * 4) if self.moving else 0
            self.rect(rv, px_ - 7, py_ + 4, 5, 12 + leg, "#2a2a38", width, height, st, at)
            self.rect(rv, px_ + 2, py_ + 4, 5, 12 - leg, "#2a2a38", width, height, st, at)
            self.rect(rv, px_ - 9, py_ - 14 + bob, 18, 20, "#b9bdd2", width, height, st, at)
            self.rect(rv, px_ - 7, py_ - 28 + bob, 14, 14, "#e3d6c8", width, height, st, at)
            self.rect(rv, px_ - 8, py_ - 31 + bob, 16, 6, "#2b1d16", width, height, st, at)

            # darkness
            self.img(rv, self.dark, 0, 0, width, height, st, at)
            for (gx, gy, fl) in lit_lamps:
                g = renpy.render(self.glow, 256, 256, st, at)
                rv.blit(g, (int(gx - 10), int(gy - 10)))

            # the figure: drawn OVER the darkness, faint, faceless, arms too long
            if self.fig_on and fd is not None:
                fx = sx(self.fig_x)
                fy = sy(self.fig_y)
                vis = max(0.25, min(0.85, 1.1 - fd / 380.0))
                a = int(vis * 255)
                col = "#c8cadc%02x" % a
                dark_col = "#05050a"
                jit = 0
                if int(st * 20) % 17 == 0:
                    jit = self.rng.randint(-5, 5)
                x = fx + jit
                self.rect(rv, x - 11, fy - 70, 22, 70, col, width, height, st, at)      # body
                self.rect(rv, x - 9, fy - 94, 18, 22, col, width, height, st, at)       # head
                self.rect(rv, x - 17, fy - 66, 6, 58, col, width, height, st, at)       # arms
                self.rect(rv, x + 11, fy - 66, 6, 58, col, width, height, st, at)
                self.rect(rv, x - 7, fy - 86, 5, 7, dark_col, width, height, st, at)    # eyes
                self.rect(rv, x + 2, fy - 86, 5, 7, dark_col, width, height, st, at)

            # static when it is close
            if fd is not None and fd < 240 and not self.calm and not self.lite:
                sr = renpy.render(Transform(self.static, zoom=4.0, alpha=min(0.5, (240 - fd) / 400.0)), width, height, st, at)
                rv.blit(sr, (-self.rng.randint(0, 60), -self.rng.randint(0, 60)))

            # a one-shot flash when it vanishes
            if st < self.flash_until and not self.calm:
                self.rect(rv, 0, 0, width, height, "#ffffff55", width, height, st, at)

            # the end: it gets very quiet and everything goes out
            if self.final_t is not None:
                p = min(1.0, (st - self.final_t) / 2.6)
                self.rect(rv, 0, 0, width, height, "#000000%02x" % int(p * 255), width, height, st, at)
                if p > 0.5:
                    t = renpy.render(self.text("You stopped.", 34, "#c8cadc"), width, height, st, at)
                    rv.blit(t, (int(width / 2 - t.get_size()[0] / 2), int(height / 2 - 20)))

            # whispers and hints
            if self.whisper_text and st < self.whisper_show_until and self.final_t is None:
                t = renpy.render(self.text(self.whisper_text, 26, "#9aa0c0"), width, height, st, at)
                rv.blit(t, (int(width / 2 - t.get_size()[0] / 2), 56))
            if st - self.t0 < 9.0 and self.final_t is None:
                msg = "Hold the left side of the screen and drag to move." if self.mobile else "Move with W A S D."
                if self.invert:
                    msg = msg + "  (It feels wrong.)"
                t = renpy.render(self.text(msg, 22, "#6e7390"), width, height, st, at)
                rv.blit(t, (int(width / 2 - t.get_size()[0] / 2), height - 56))

            # virtual joystick
            if self.joy_on or (self.mobile and st - self.t0 < 9.0):
                if self.joy_on:
                    ox_, oy_ = self.joy_o
                    jx, jy = self.joy_vec()
                    kx = ox_ + jx * 90.0
                    ky = oy_ + jy * 90.0
                else:
                    ox_, oy_ = 170, height - 150
                    kx, ky = ox_, oy_
                self.img(rv, self.joy_base, ox_ - 100, oy_ - 100, width, height, st, at)
                self.img(rv, self.joy_knob, kx - 42, ky - 42, width, height, st, at)

            renpy.redraw(self, 0)
            return rv

        def per_interact(self):
            renpy.redraw(self, 0)

        def visit(self):
            return [self.glow, self.dark, self.joy_base, self.joy_knob, self.static]

    class E404Poll(renpy.ui.Action):
        """Ends the walk screen once the ending has played."""
        def __call__(self):
            w = E404P7Hold.walk
            if w is not None and w.done:
                return "end"
            return None

    def e404_p7_start_walk():
        st = renpy.store
        mobile = (st.e404_device == "mobile")
        E404P7Hold.walk = E404Walk(mobile=mobile, invert=bool(st.e404_p7_invert),
                                   calm=bool(st.e404_p7_calm or st.e404_p2_reduce_flashing),
                                   lite=bool(st.e404_p3_lite))
        try:
            renpy.music.stop(channel="music", fadeout=1.0)
            if not st.e404_p3_lite:
                renpy.music.play("error_404/assets/audio/e404_p3_drone.wav", channel="e404_amb", loop=True, fadein=2.0)
        except Exception:
            pass

    def e404_p7_end_walk():
        try:
            E404P7Hold.walk = None
            renpy.music.stop(channel="e404_hb", fadeout=0.5)
            renpy.music.stop(channel="e404_step")
            renpy.music.stop(channel="e404_amb", fadeout=2.0)
        except Exception:
            pass

init 1999 python:
    for _ch in ("e404_hb", "e404_step"):
        try:
            renpy.music.register_channel(_ch, mixer="sfx", loop=(_ch == "e404_hb"))
        except Exception as e:
            print("[E404] channel " + _ch + " FAILED: " + repr(e))
