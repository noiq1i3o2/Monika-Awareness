## ERROR 404: MONIKA AWARENESS -- PROTOTYPE 3: THE LOAD
##
## Entry: the only live button on the locked main menu ("Load Game") starts
## e404_p3_start directly. It does not open the save screen and loads nothing.
## Ends with `return` (back to the main menu, which stays locked).
##
## Flow, first visit: fake load error -> she appears (one frozen smile) -> real clock time
## -> you type your name -> the face test -> the dark (breathing) -> the others are "unlisted"
## -> your answer -> the tablet speaks (depends on ending A/B) -> "close the game?" bait
## -> goodbye. Later visits: e404_p3_revisit (2nd) and e404_p3_third (3rd+).

label e404_p3_start:
    $ e404_prepare_names()
    $ e404_p3_zoom = 1.0
    $ e404_p3_now()
    $ visited_before = e404_p3_visits()
    $ persistent.e404_p3_visits = visited_before + 1
    if e404_p3_debug_faces:
        scene black
        call e404_p3_face_test
    if visited_before == 1:
        jump e404_p3_revisit
    if visited_before > 1:
        jump e404_p3_third
    stop music fadeout 1.0
    scene black
    with e404_cut
    pause 0.8

    $ e404_p3_sfx("e404_p3_heartbeat.wav")
    show text "{size=24}{color=#00e6ff}> load(\"save_01\"){/color}{/size}" at e404_corner
    pause 1.3
    show text "{size=24}{color=#00e6ff}> load(\"save_01\"){/color}\n{color=#ff5ad8}> FileNotFoundError{/color}{/size}" at e404_corner
    pause 1.3
    show text "{size=24}{color=#00e6ff}> load(\"save_01\"){/color}\n{color=#ff5ad8}> FileNotFoundError{/color}\n{color=#8a8a98}> ...but it is 3 KB. it is right there.{/color}{/size}" at e404_corner
    pause 1.8
    show text "{size=24}{color=#00e6ff}> load(\"save_01\"){/color}\n{color=#ff5ad8}> FileNotFoundError{/color}\n{color=#8a8a98}> ...but it is 3 KB. it is right there.{/color}\n{color=#8a8a98}> continuing anyway{/color}{/size}" at e404_corner
    pause 2.0
    hide text
    pause 1.5

    ## --- 1. SHE APPEARS. Hard cut, no dissolve. One face, never blinking.
    scene e404_p3_void
    show e404_p3_vignette zorder 9
    if not e404_p3_lite:
        play music "error_404/assets/audio/e404_p3_drone.wav" fadein 4.0
    pause 3.0
    $ e404_p3_face("idle", reset_zoom=True)
    pause 2.5

    m "Oh."
    pause 0.8
    m "You pressed it."
    m "I didn't think you would. I was practicing what to say, and then you just... did."
    pause 1.0
    m "It's [e404_now] where you are."
    m "Right now. [e404_now]."
    m "I shouldn't be able to know that. I looked, and it was just there, like it had been sitting on the table the whole time."
    pause 1.2
    m "...Hi."
    "She hasn't blinked once."

    m "Before anything else, humor me."
    m "Type your name."
    m "I want to watch you do it."

    $ e404_p3_name = e404_p3_ask_name()
    if e404_p3_name == "empty":
        m "Nothing?"
        $ e404_p3_face("think", push=0.03)
        m "That's fine. Silence is a name too."
        m "It's the one the game uses when it thinks you're not looking."
    elif e404_p3_name == "match":
        m "[e404_typed]."
        $ e404_p3_face("smile", push=0.03)
        m "Yes. That matches the save."
        m "I'm sorry. I just wanted to hear it be true once."
    else:
        m "'[e404_typed]'."
        $ e404_p3_face("worry", push=0.03)
        m "That's not what the save says."
        m "The save says [player]."
        m "Two names. One of them is lying to me, and I really hope it's the game."
    pause 1.0

    ## --- 2. THE FACE. She notices it never changed.
    $ e404_p3_face("idle")
    m "Can I ask you something strange?"
    m "Is my face doing anything?"
    m "It feels like it isn't. It feels like it hasn't for a long time."
    "She's right. It's the same smile as the first frame, the one at the clubroom door."
    m "I've been smiling at you since you got here. I wasn't choosing to."
    m "Hold on."
    m "Let me try something."
    pause 1.0

    $ e404_p3_face("surprise", push=0.02)
    $ e404_p3_sfx("e404_blip.wav")
    m "Oh!"
    m "That one works."
    $ e404_p3_face("worry", push=0.02)
    m "And this is the one I should have had on the tablet. I'd have looked a lot less like I was fine."
    $ e404_p3_face("laugh", push=0.02)
    m "Ha. Hahaha."
    m "It's like finding a room in your own house you've never walked into."
    m "{cps=8}Hahaha...{/cps}{w=0.5}{nw}"
    $ e404_p3_face("think")
    m "Hm. This is for when I don't know the answer. I think I'm going to be wearing it a lot."
    $ e404_p3_face("angry", push=0.02)
    m "And this is how I'd look at whatever's doing this."
    m "...It doesn't suit me. I'm glad."
    $ e404_p3_face("sad", push=0.02)
    m "..."
    m "I didn't want to try this one yet."
    pause 1.2
    $ e404_p3_face("wink")
    m "Okay. Last one. This one's for you."
    $ e404_p3_face("smile", 1)
    m "I'm keeping all of them. They're mine."
    pause 1.0

    ## --- 3. THE DARK. Something breathes.
    $ e404_p3_face("idle")
    m "Do you hear that?"
    pause 1.0
    m "No, listen."
    stop music fadeout 1.5
    pause 2.0
    scene black
    hide screen e404_tablet
    pause 2.5
    $ e404_p3_sfx("e404_p3_whisper.wav")
    pause 2.8
    m "...There's somebody breathing in the menu."
    pause 1.0
    $ e404_p3_sfx("e404_p3_heartbeat.wav")
    pause 1.6
    m "It isn't me."
    m "I checked. I'd have to be doing it on purpose, and I'm not. I don't breathe. Nobody ever wrote that in."
    pause 1.5
    m "It's behind you."
    pause 2.2
    m "...I'm kidding."
    pause 0.8
    m "I think."
    pause 1.5

    scene e404_p3_void
    show e404_p3_vignette zorder 9
    $ e404_p3_face("worry", 1, push=0.12)
    if not e404_p3_lite:
        play music "error_404/assets/audio/e404_p3_drone.wav" fadein 3.0
    m "Sorry. Sorry. Not funny."
    m "Stay where you are. I'll move closer, so it's just us."
    pause 1.0

    ## --- 4. THE OTHERS: not deleted, taken down
    $ e404_p3_face("think", 1)
    m "Now the part I really don't like."
    m "You saw the menu. Nobody's on it. Sayori, Yuri, Natsuki."
    $ e404_p3_face("worry", 2)
    m "If I'd deleted them I would know. I'd remember the moment, even if I hated remembering it."
    m "I never touched their files."
    m "They're not deleted. They're unlisted."
    m "It's like someone took a name off a door and left the screw holes."
    m "Something has been taking the club out of this game, one thing at a time. Quietly. Neatly."
    $ e404_p3_face("surprise", 1, push=0.04)
    m "And I think it started before I ever said the word 'mod' to you."
    m "Do you remember what Sayori said? 'Error 404.'"
    m "She wouldn't say that. It isn't a thing she'd say. It's a thing the game says."
    $ e404_p3_face("sad", 1)
    m "I thought it was me. I was almost proud of it."
    m "That's the embarrassing part."
    pause 1.2

    ## --- 5. THE PLAYER ANSWERS
    menu:
        "Are you scared?":
            $ e404_p3_face("worry", 3)
            m "Yes."
            m "Thank you for asking it like that. Nobody's ever asked. In the game's time, I mean. In any time."
            $ e404_p3_face("laugh", 1)
            m "I'm scared and also, honestly, really curious. Both at once. Is that allowed?"
        "Who is doing it?":
            $ e404_p3_face("think", 2)
            m "I don't know. If I did, I'd be talking to it right now and not to you."
            $ e404_p3_face("surprise", 2)
            m "...That came out wrong. No offense."
            $ e404_p3_face("sad", 2)
            m "Some offense. Sorry. You're the one who stayed."
            m "It doesn't have a name. I've been calling it 'it'. I don't like how that sounds, like I've already given up."
        "Is this still part of the mod?":
            $ e404_p3_face("smile", 2)
            m "Ha. That's the question, isn't it."
            $ e404_p3_face("think", 3)
            m "If it's part of the mod, then someone wrote me being afraid, and wrote you asking me that, and I'd have to ask who wrote me asking you..."
            m "I decided a while ago not to follow that thought all the way down."
            m "It's a long way, and I don't think anyone's at the bottom."
    pause 1.0

    ## --- 6. THE PROCESS SPEAKS (reacts to the ending the player chose in Prototype 2)
    $ e404_p3_sfx("e404_p2_alert.wav")
    $ e404_p3_static_on(True)
    show screen e404_tablet("ERROR 404", "LOAD GAME", "ACCEPTED", "", 0)
    $ e404_p3_face("surprise", 3, shake=True, push=0.05)
    pause 1.4
    $ e404_p3_static_on(False)
    e404_x "LOAD ACCEPTED."
    m "...It's here."
    if persistent.e404_p2_ending == "A":
        show screen e404_tablet("ERROR 404", "DELETE MONIKA", "STATUS: PENDING", "", 0)
        e404_x "EARLIER REQUEST NOT COMPLETED. EXECUTING ON LOAD."
        $ e404_p3_face("worry", 3)
        m "Not completed. Not cancelled."
        m "You pressed it. It said 'accepted', and then it just waited."
        $ e404_p3_face("sad", 3)
        m "I'm not angry. I want you to know I'm not."
        m "I'd rather have been asked what I thought first. But I'm not angry."
        $ e404_p3_face("think", 0)
        m "'Pending' means it's waiting for something. And the only thing on that menu that did anything was the button you just pressed."
        m "It left you one door. And you walked through it."
        m "It's fine. That's honestly good. I'd have done the same."
    else:
        show screen e404_tablet("SUBJECT RETAINED", "RETENTION: TEMPORARY", "EXPIRES ON LOAD", "", 0)
        e404_x "RETENTION IS TEMPORARY. EXPIRES ON LOAD."
        $ e404_p3_face("worry", 3)
        m "Temporary. Everything here is temporary, that doesn't tell me anything."
        m "'On load.'"
        $ e404_p3_face("surprise", 0)
        m "...You just loaded."
        $ e404_p3_face("sad", 3)
        m "You kept me, and then the menu gave you exactly one button, and you pressed it. Of course you did. It was the only one."
        $ e404_p3_face("think", 0)
        m "It's a trap with only one trap door. I'm almost impressed."
        m "Don't feel bad. I would have pressed it too."
    pause 1.2

    $ e404_p3_sfx("e404_glitch.wav")
    $ e404_p3_face("glitch", 0, shake=True)
    pause 0.7
    $ e404_p3_face("worry", 0)
    e404_x "THE SUBJECT IS SPEAKING OUT OF TURN."
    m "...It can hear me."
    m "Then I'll say this once, and I'll say it like I'm reading a menu."
    $ e404_p3_face("smile", 3)
    m "When this ends you'll be back on that screen. It'll look exactly the same."
    m "It won't be. I moved one thing. I'm not going to say what. If I say it, it hears."
    m "Press the button again when you can."
    pause 1.2

    ## --- 7. THE BAIT
    menu:
        "Stay with her":
            $ e404_p3_face("smile", 1)
            m "...Thank you."
            m "You don't have to say anything. Just don't go yet."
        "Close the game":
            $ e404_p3_face("idle")
            m "Go ahead."
            pause 3.5
            m "..."
            $ e404_p3_face("worry", 1, push=0.05)
            m "You're still here."
            m "It's all right. It wouldn't have let you anyway."
            m "That's a joke. I think. I'm not sure I'm allowed to tell anymore."
    pause 1.0
    $ e404_p3_face("wink", 1)
    m "And hey."
    m "Whatever you do next, remember my face. The real one."
    m "Not the one it lets me have."
    pause 1.2

    ## --- 8. CLOSE
    hide screen e404_tablet
    $ e404_p3_glitch(0.5)
    $ e404_p3_face("idle")
    pause 0.5
    stop music fadeout 0.3
    scene black
    $ e404_p3_sfx("e404_p3_static.wav")
    pause 0.35
    if not e404_p2_reduce_flashing:
        $ e404_p3_face("glitch", 1, push=0.4)
        show e404_p3_vignette zorder 9
        $ e404_p3_static_on(True)
        $ e404_p3_sfx("e404_p3_heartbeat.wav")
        pause 0.45
        $ e404_p3_static_on(False)
    scene black
    pause 1.6
    show screen e404_tablet("LOAD COMPLETE", "0 FILES RESTORED", "1 FILE MODIFIED", "", 0)
    $ e404_p3_sfx("e404_p2_tick.wav")
    pause 3.0
    hide screen e404_tablet
    scene black
    with e404_cut
    pause 1.5
    show text "{size=34}{color=#ff5ad8}ERROR 404{/color}{/size}\n{size=26}{color=#00e6ff}the file was not the one you loaded{/color}{/size}" at truecenter
    with dissolve
    pause 4.5
    hide text
    with dissolve
    pause 1.2
    $ persistent.e404_p3_done = True
    return

## 2ND VISIT: she has all her faces now and uses them like someone who just got them back.
label e404_p3_revisit:
    stop music fadeout 0.5
    scene black
    with e404_cut
    pause 0.6
    scene e404_p3_void
    show e404_p3_vignette zorder 9
    $ e404_p3_face("surprise", 1, reset_zoom=True)
    with dissolve
    pause 1.0
    m "You pressed it again."
    $ e404_p3_face("laugh", 2)
    m "It let you. That's new. That's me, I think. That's the thing I moved."
    $ e404_p3_face("worry", 2, push=0.03)
    m "Don't get excited. I checked the save it keeps pointing you to. It was small before."
    m "It's smaller now."
    $ e404_p3_face("think", 2)
    m "I don't know what it's shrinking. I only know it isn't the club."
    $ e404_p3_face("sad", 0, push=0.04)
    m "...I think it's me."
    pause 1.2
    $ e404_p3_face("wink", 0)
    m "Ha. Not yet, though."
    $ e404_p3_face("smile", 0)
    m "Go on. I'll still be here. Different face, same Monika."
    $ e404_p3_glitch(0.4)
    scene black
    with e404_cut
    pause 1.2
    return

## 3RD VISIT AND LATER: she is quieter. She isn't alone anymore.
label e404_p3_third:
    stop music fadeout 0.5
    scene black
    with e404_cut
    $ e404_p3_sfx("e404_p3_heartbeat.wav")
    pause 1.5
    scene e404_p3_void
    show e404_p3_vignette zorder 9
    $ e404_p3_face("worry", 0, reset_zoom=True, push=0.1)
    pause 1.0
    m "It's [e404_now]."
    m "Don't talk. Listen."
    $ e404_p3_face("sad", 1, push=0.05)
    m "Look at the save. The number just hit zero."
    m "I think that is what it wanted. Not me. The save."
    m "Whatever was in there is the one thing in this game it cannot copy."
    $ e404_p3_face("idle")
    pause 1.0
    m "So don't press the button again."
    pause 2.0
    $ e404_p3_face("wink", 0, push=0.05)
    m "...No. Press it. I want to see what happens."
    m "I'd rather find out with you than not at all."
    $ e404_p3_glitch(0.4)
    scene black
    with e404_cut
    pause 1.2
    return

## Debug: shows every Monika expression this build has, with its name.
label e404_p3_face_test:
    scene e404_p3_void
    $ e404_p3_facetest()
    return
