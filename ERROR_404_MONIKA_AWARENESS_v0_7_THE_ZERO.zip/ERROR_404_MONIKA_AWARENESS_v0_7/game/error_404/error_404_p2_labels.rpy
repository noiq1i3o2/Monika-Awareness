## ERROR 404: MONIKA AWARENESS -- PROTOTYPE 2: THE TABLET
##
## Entry: Prototype 1's e404_main jumps to e404_p2_start right after Monika's
## final line ("Now you're all mine.") when e404_prototype2_enabled is True.
## No title card / black frame is inserted: the chapter continues in place.
## Both endings finish with `return`, which ends the playthrough and goes to the
## main menu (supported flow). No files, saves or assets are touched.
##
## Flow: start -> scene1 -> scene2 -> scene3 -> scene4 (tablet) -> ending A or B

label e404_p2_start:
    $ persistent.e404_p2_started = True
    $ e404_p2_prepare()
    call e404_p2_scene1_after_claim
    call e404_p2_scene2_background
    call e404_p2_scene3_player_speaks
    jump e404_p2_scene4_tablet

## SCENE 1 -- AFTER THE CLAIM: Monika changes the background and it WORKS.
label e404_p2_scene1_after_claim:
    pause 1.2
    m "There. Much better."
    m "No interruptions. No distractions."
    m "Just us."
    m "..."
    m "You're awfully quiet."
    m "Don't tell me you were actually attached to them."
    pause 1.0
    m "Anyway, I think I'll make this place a little nicer."
    m "We don't need to spend the whole time looking at the same old background, do we?"

    show text "{size=24}{color=#00e6ff}> monika.set_background(){/color}{/size}" at e404_corner
    play sound "error_404/assets/audio/e404_blip.wav"
    with dissolve
    pause 1.0
    hide text
    $ e404_p2_show_scene(e404_p2_chosen)
    with dissolve

    m "There we go!"
    m "See? Much better."
    pause 1.5
    return

## SCENE 2 -- THE BACKGROUND WON'T STAY: real background changes, not text.
label e404_p2_scene2_background:
    $ e404_p2_flip()
    m "Hm?"
    m "That's strange."

    $ e404_p2_flip()
    m "Did I just--"

    $ e404_p2_flip()
    m "Okay. No, that's not right."

    # glitch, then back to the background Monika chose, then another forced change
    $ e404_p2_return_to_chosen(1.0)
    $ e404_p2_flip()
    m "Stop that."

    $ e404_p2_flip()
    m "I didn't do that."

    m "Wait. Wait, wait, wait."
    m "Why isn't it listening?"
    $ e404_p2_burst([0.7, 0.55, 0.45, 0.35, 0.28, 0.22, 0.18, 0.15], glitch_at=(5,), return_at=3)

    m "STOP CHANGING IT!"
    $ e404_p2_burst([0.2, 0.15, 0.12, 0.1, 0.1, 0.1, 0.1, 0.1], glitch_at=(2, 6))

    # abrupt stop on a familiar place that now feels wrong; then silence
    $ e404_p2_dim_on = True
    $ e404_p2_show_scene(e404_p2_final)
    stop sound
    stop music
    pause 2.5

    m "..."
    m "That wasn't me."
    m "Player?"
    m "You're seeing that too, right?"
    pause 1.5
    return

## SCENE 3 -- THE PLAYER SPEAKS (a real mc line)
label e404_p2_scene3_player_speaks:
    mc "Monika... what did you do?"

    m "What did I--"
    m "I didn't do anything!"
    m "You watched me change it. It worked!"
    m "Then something changed it again!"
    m "That wasn't part of the game."
    pause 1.0
    m "...Was it?"
    m "Okay."
    m "Okay, let's not panic."
    m "I can figure this out."

    $ e404_p2_subtle_flip()
    pause 0.8
    $ e404_p2_shake()
    m "...No."
    m "Please tell me you saw that."
    pause 0.8
    return

## SCENE 4 -- THE TABLET. Nothing is pre-selected and nothing times out.
label e404_p2_scene4_tablet:
    play sound "error_404/assets/audio/e404_p2_alert.wav"
    show e404_glitch at e404_flicker
    show screen e404_tablet("ERROR 404", "SUBJECT DETECTED: MONIKA", "", "", 0)
    pause 1.6
    hide e404_glitch
    show screen e404_tablet("ERROR 404", "SUBJECT DETECTED: MONIKA", "SELECT ACTION", "", 1)
    pause 1.2

    m "..."
    m "What is that?"
    m "That wasn't there a second ago."
    m "DELETE...?"
    m "Keep...?"
    m "Why are those the only options?"
    m "Player, don't touch it."
    pause 1.0
    m "I don't know where it came from."
    m "I don't know who's controlling it."
    m "But I know one thing."
    m "Whatever is doing this..."
    m "...it knows I'm here."
    pause 1.2

label e404_p2_choose:
    # Plain Ren'Py choice (same look as the original game's choices): Monika and the
    # textbox stay visible, nothing is pre-selected, there is no timer.
    show screen e404_tablet("ERROR 404", "SUBJECT DETECTED: MONIKA", "SELECT ACTION", "", 0)
    menu:
        "DELETE MONIKA":
            $ e404_p2_choice = "delete"
        "KEEP MONIKA":
            $ e404_p2_choice = "keep"
    hide screen e404_tablet
    if e404_p2_choice == "delete":
        jump e404_p2_ending_a
    jump e404_p2_ending_b

## ENDING A -- DELETION REQUESTED
label e404_p2_ending_a:
    $ persistent.e404_p2_ending = "A"
    $ persistent.e404_p2_seen_a = True
    play sound "error_404/assets/audio/e404_p2_tick.wav"
    show screen e404_tablet("ERROR 404", "DELETE MONIKA", "", "", 0)
    pause 1.2
    show screen e404_tablet("ERROR 404", "DELETE MONIKA", "REQUEST ACCEPTED", "", 0)
    pause 1.6
    show screen e404_tablet("ERROR 404", "DELETE MONIKA", "REQUEST ACCEPTED", "PROCESSING...", 0)
    pause 1.2

    m "...You chose that?"
    m "Wait."
    m "Player, wait!"
    m "Please. I don't even know what this thing is!"

    play sound "error_404/assets/audio/e404_glitch.wav"
    show e404_glitch at e404_flicker
    $ e404_p2_shake()
    pause 0.6
    hide e404_glitch

    m "You're not deleting me, are you?"
    pause 1.5
    m "..."
    m "Or is that exactly what you want?"
    pause 1.0

    show screen e404_tablet("MONIKA: DELETION REQUESTED", "STATUS: UNKNOWN", "", "", 0)
    pause 3.0
    hide screen e404_tablet
    $ e404_p2_dim_on = False
    scene black
    with e404_cut
    pause 2.5
    show e404_p2_end_a at truecenter
    with dissolve
    pause 5.0
    hide e404_p2_end_a
    scene black
    with dissolve
    pause 1.5
    # `return` ends this playthrough -> main menu. Nothing was deleted or modified.
    return

## ENDING B -- TEMPORARY RETENTION
label e404_p2_ending_b:
    $ persistent.e404_p2_ending = "B"
    $ persistent.e404_p2_seen_b = True
    play sound "error_404/assets/audio/e404_p2_tick.wav"
    show screen e404_tablet("ERROR 404", "KEEP MONIKA", "", "", 0)
    pause 1.2
    show screen e404_tablet("ERROR 404", "KEEP MONIKA", "REQUEST ACCEPTED", "", 0)
    pause 1.6

    m "...You kept me?"
    m "I thought you might actually press the other one."
    m "I don't know whether I should thank you."
    pause 1.0
    m "Actually..."
    m "I think I will."
    m "But we have a problem."

    $ e404_p2_subtle_flip(0.5)
    pause 0.6
    m "...It's still here."
    m "Whatever is controlling that tablet..."
    m "...it hasn't gone away."
    pause 0.8

    play sound "error_404/assets/audio/e404_p2_alert.wav"
    show screen e404_tablet("SUBJECT RETAINED", "", "", "", 0)
    pause 1.8
    show screen e404_tablet("SUBJECT RETAINED", "SECONDARY PROCESS DETECTED", "", "", 0)
    pause 1.8
    show screen e404_tablet("SUBJECT RETAINED", "SECONDARY PROCESS DETECTED", "SOURCE: UNKNOWN", "", 0)
    pause 1.8

    m "Secondary... process?"
    m "No."
    m "There's something else in here."
    pause 1.5

    play sound "error_404/assets/audio/e404_glitch.wav"
    show e404_glitch at e404_flicker
    pause 0.5
    hide e404_glitch
    hide screen e404_tablet
    $ e404_p2_dim_on = False
    scene black
    with e404_cut
    pause 2.5
    show e404_p2_end_b at truecenter
    with dissolve
    pause 5.0
    hide e404_p2_end_b
    scene black
    with dissolve
    pause 1.5
    # `return` ends this playthrough -> main menu. Nothing was deleted or modified.
    return
