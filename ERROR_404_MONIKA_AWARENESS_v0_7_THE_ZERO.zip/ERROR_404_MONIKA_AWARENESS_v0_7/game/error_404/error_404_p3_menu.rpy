## ERROR 404: MONIKA AWARENESS -- THE VOID MENU (shown from the very first launch)
## Replaces DDLC's main menu: drawn ON TOP of it (screen layer, modal), so DDLC's own
## screens.rpy is never edited. Black void, Monika alone: worried, trembling, sweating.
## Title "Doki Doki Literature Club" with "Monika Awareness" under it, version bottom-right.
##
## State 1 (new player): New Game / Load Game / Settings / Quit all work (they open DDLC's own screens).
## State 2 (after Ending A or B in Prototype 2): everything is dead except LOAD GAME, which
## starts the Prototype 3 scene instead of the save screen. No game files are touched.
##
## Sweat drops: tweak the xpos/ypos in the three e404_sweat_* transforms if they don't sit on her forehead.
## Switches (error_404_p3_events.rpy): e404_menu_enabled, e404_p3_menu_lock, e404_p3_lite.
define e404_version_label = "V0.7"

transform e404_menu_monika:
    xanchor 0.5
    xpos 640
    yanchor 1.0
    ypos 1.03
    zoom 1.0
    ease 3.0 zoom 1.025
    ease 3.0 zoom 1.0
    repeat

transform e404_menu_monika_lite:
    xanchor 0.5
    xpos 640
    yanchor 1.0
    ypos 1.03

## she is trembling
transform e404_shiver:
    xoffset 0
    linear 0.05 xoffset 2
    linear 0.05 xoffset -2
    linear 0.05 xoffset 1
    linear 0.05 xoffset -1
    repeat

transform e404_menu_jitter:
    xoffset 0
    pause 2.4
    linear 0.04 xoffset 10
    linear 0.04 xoffset -8
    linear 0.04 xoffset 0
    pause 1.1
    linear 0.03 xoffset -14
    linear 0.03 xoffset 6
    linear 0.03 xoffset 0
    pause 3.2
    repeat

transform e404_menu_pulse:
    alpha 0.0
    pause 3.0
    linear 0.05 alpha 0.8
    linear 0.05 alpha 0.2
    linear 0.08 alpha 0.6
    linear 0.15 alpha 0.0
    pause 4.1
    linear 0.05 alpha 0.5
    linear 0.1 alpha 0.0
    pause 2.4
    repeat

transform e404_menu_label_flicker:
    alpha 1.0
    pause 3.3
    alpha 0.35
    pause 0.06
    alpha 1.0
    pause 0.1
    alpha 0.5
    pause 0.05
    alpha 1.0
    repeat

transform e404_sweat_a:
    xpos 700
    ypos 118
    alpha 0.0
    pause 0.0
    block:
        ypos 118
        alpha 0.0
        linear 0.25 alpha 0.85
        linear 1.7 ypos 213 alpha 0.0
        pause 1.2
        repeat

transform e404_sweat_b:
    xpos 590
    ypos 130
    alpha 0.0
    pause 1.1
    block:
        ypos 130
        alpha 0.0
        linear 0.25 alpha 0.85
        linear 1.7 ypos 225 alpha 0.0
        pause 1.2
        repeat

transform e404_sweat_c:
    xpos 722
    ypos 170
    alpha 0.0
    pause 2.2
    block:
        ypos 170
        alpha 0.0
        linear 0.25 alpha 0.85
        linear 1.7 ypos 265 alpha 0.0
        pause 1.2
        repeat

image e404_p3_sweat = "error_404/assets/ui/e404_p3_sweat.png"


transform e404_title_cyan:
    xoffset -3
    pause 2.6
    xoffset -9
    pause 0.05
    xoffset -3
    repeat

transform e404_title_magenta:
    xoffset 3
    pause 2.6
    xoffset 11
    pause 0.05
    xoffset 3
    repeat

screen e404_menu_lock():
    zorder 500
    modal True

    add "e404_p3_void"

    ## ---- Monika in the void ----
    fixed at e404_menu_jitter:
        if e404_p3_lite:
            add DynamicDisplayable(e404_menu_face) at e404_menu_monika_lite
        else:
            fixed at e404_shiver:
                add DynamicDisplayable(e404_menu_face) at e404_menu_monika

    add "e404_p3_sweat" at e404_sweat_a
    add "e404_p3_sweat" at e404_sweat_b
    add "e404_p3_sweat" at e404_sweat_c

    add "e404_glitch" at e404_menu_pulse
    if not e404_p3_lite:
        add "e404_p3_static" at e404_p3_noise
    add "e404_p3_vignette"

    ## ---- title ----
    fixed:
        xpos 48
        ypos 30
        xysize (760, 110)
        text "Doki Doki Literature Club" size 46 color "#00e6ff" at e404_title_cyan
        text "Doki Doki Literature Club" size 46 color "#ff5ad8" at e404_title_magenta
        text "Doki Doki Literature Club" size 46 color "#f4f4fa"
        text "Monika Awareness" size 30 color "#00e6ff" xpos 4 ypos 64 kerning 4

    add DynamicDisplayable(e404_menu_clock) xalign 0.97 ypos 26

    ## ---- version (bottom right) ----
    text e404_version_label size 24 color "#8a8a98" xalign 0.98 yalign 0.98

    if e404_menu_locked():
        ## ---- STATE 2: only Load Game is alive ----
        add DynamicDisplayable(e404_menu_whisper) xpos 52 ypos 118
        vbox:
            xpos 52
            yalign 0.97
            spacing 4
            text "sayori.chr   natsuki.chr   yuri.chr  :  MISSING" size 20 color "#8a8a98"
            text ("save_01.sav  :  " + str(e404_p3_save_kb()) + " KB") size 20 color "#8a8a98"
        vbox:
            xalign 0.93
            yalign 0.6
            spacing 12
            textbutton "New Game":
                action None
                sensitive False
                text_size 40
                text_insensitive_color "#34344a"
                xalign 1.0
            textbutton "LOAD GAME":
                action (Start("e404_p7_start") if e404_p3_save_kb() <= 0 else Start("e404_p3_start"))
                text_size 46
                text_idle_color "#00e6ff"
                text_hover_color "#ff5ad8"
                xalign 1.0
                at e404_menu_label_flicker
            textbutton "Settings":
                action None
                sensitive False
                text_size 40
                text_insensitive_color "#34344a"
                xalign 1.0
            textbutton "Quit":
                action None
                sensitive False
                text_size 40
                text_insensitive_color "#34344a"
                xalign 1.0
    else:
        ## ---- STATE 1: a normal menu, in the void ----
        vbox:
            xalign 0.93
            yalign 0.6
            spacing 12
            textbutton "New Game":
                action Start()
                text_size 44
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5ad8"
                xalign 1.0
            textbutton "Load Game":
                action (Start("e404_p7_start") if e404_p7_test_start else ShowMenu("load"))
                text_size 44
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5ad8"
                xalign 1.0
            textbutton "Settings":
                action ShowMenu("preferences")
                text_size 44
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5ad8"
                xalign 1.0
            textbutton "Quit":
                action Quit(confirm=True)
                text_size 44
                text_idle_color "#e9e9f2"
                text_hover_color "#ff5ad8"
                xalign 1.0
