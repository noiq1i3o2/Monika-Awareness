## ERROR 404: MONIKA AWARENESS -- v0.7: THE ZERO
##
## Entry: the void menu's LOAD GAME once the save reads 0 KB (see error_404_p3_menu.rpy),
## or at once when e404_p7_test_start is True.
##
## error -> [Go Back -> "Are you sure?" -> Yes: reset the mod / No: back to the error]
##       -> [Continue Anyway -> glitched Sayori, Yuri, Natsuki (no Monika), one line each]
##       -> the walk home (nobody runs up to you) -> device choice -> the walkable street
##
## Nothing outside this mod is deleted. "Reset" only clears this mod's own persistent flags.

label e404_p7_start:
    $ e404_prepare_names()
    $ config.rollback_enabled = False
    stop music fadeout 0.5
    scene black
    with e404_cut
    pause 1.2
    $ e404_p3_sfx("e404_p2_alert.wav")

label e404_p7_error_loop:
    call screen e404_p7_error
    $ e404_p7_answer = _return
    if e404_p7_answer == "back":
        $ e404_p3_sfx("e404_blip.wav")
        call screen e404_p7_confirm
        $ e404_p7_sure = _return
        if e404_p7_sure == "yes":
            jump e404_p7_reset
        jump e404_p7_error_loop
    jump e404_p7_continue

## ---------------- "Yes": wipe this mod's own progress and start over ----------------
label e404_p7_reset:
    scene black
    with e404_cut
    show text "{size=26}{color=#ff5a6e}deleting...{/color}{/size}" at truecenter
    $ e404_p3_sfx("e404_glitch.wav")
    pause 1.6
    show text "{size=26}{color=#8a8a98}deleting backups...{/color}{/size}" at truecenter
    pause 1.6
    show text "{size=26}{color=#8a8a98}nothing left to delete.{/color}{/size}" at truecenter
    pause 1.8
    hide text
    $ e404_p7_reset_game()
    $ e404_p7_restore_title()
    scene black
    with e404_cut
    pause 1.0
    $ renpy.full_restart()
    return

## ---------------- "Continue Anyway": the empty chairs ----------------
label e404_p7_continue:
    $ persistent.e404_p7_seen = True
    $ e404_p3_sfx("e404_glitch.wav")
    scene black
    with e404_cut
    pause 1.4

    $ e404_p7_show_glitched("sayori 1a", "e404_card_sayori")
    with e404_cut
    pause 0.7
    s "[e404_p7_line_sayori]"
    "The voice is hers. The mouth is a half-second late."
    $ renpy.hide("e404_glitch")
    scene black
    with e404_cut
    pause 1.0

    $ e404_p7_show_glitched("yuri 1a", "e404_card_yuri")
    with e404_cut
    pause 0.7
    y "[e404_p7_line_yuri]"
    "She is looking at me. She is also looking at something behind me."
    scene black
    with e404_cut
    pause 1.0

    $ e404_p7_show_glitched("natsuki 1a", "e404_card_natsuki")
    with e404_cut
    pause 0.7
    n "[e404_p7_line_natsuki]"
    "Her sentence ends. The silence after it does not."
    scene black
    with e404_cut
    pause 1.6

    # the fourth chair: nobody comes
    scene e404_p7_void
    show e404_p3_vignette zorder 9
    with dissolve
    pause 2.4
    "There should be a fourth voice here."
    "There is only the shape of where it used to be."
    $ e404_p3_sfx("e404_p3_heartbeat.wav")
    pause 2.2
    scene black
    with e404_cut
    pause 1.4
    jump e404_p7_walk_home

## ---------------- the walk home ----------------
label e404_p7_walk_home:
    $ e404_bg("bg residential_day", "e404_bg_street")
    with Fade(1.2, 0.5, 1.2)
    pause 1.0
    "The walk home."
    "This is where it began."
    "Every morning, someone runs up behind me, out of breath and smiling."
    "I stand on the sidewalk and I wait."
    pause 2.5
    "Nobody comes."
    pause 1.5
    "Even the wind has stopped."
    pause 1.5

    call screen e404_p7_device
    $ e404_p7_device_choice = _return
    $ e404_p7_wrong = e404_p7_apply_device(e404_p7_device_choice)
    $ e404_p3_sfx("e404_blip.wav")
    if e404_p7_wrong and e404_p7_punish_wrong_device:
        pause 0.8
        $ e404_p3_sfx("e404_glitch.wav")
        "...That was not true."
        "The street knows what you are holding."
        pause 1.0
    else:
        pause 0.6
        "The street accepts your answer. That is almost worse."
        pause 0.8

    scene black
    with Fade(0.8, 0.8, 1.2)
    pause 0.6
    $ e404_p7_start_walk()
    call screen e404_p7_walk
    $ e404_p7_end_walk()
    $ e404_p7_restore_title()

    # ---- the end of this build ----
    scene black
    with e404_cut
    pause 2.0
    $ e404_p3_sfx("e404_p3_whisper.wav")
    e404_x "You stopped."
    e404_x "Good. Now you are somewhere I can find you."
    pause 1.5
    show text "{size=34}{color=#ff5ad8}ERROR 404{/color}{/size}\n{size=26}{color=#00e6ff}the street continues in v0.8{/color}{/size}" at truecenter
    with dissolve
    pause 4.5
    hide text
    with dissolve
    pause 1.2
    $ persistent.e404_p7_finished = True
    return
