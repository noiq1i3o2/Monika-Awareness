## ERROR 404: MONIKA AWARENESS -- PROTOTYPE 3: THE LOAD
## Helpers: Monika's expression pools, the "???" speaker, creep effects, the locked-menu logic.
## Python 2 compatible (DDLC = Ren'Py 6.99). Every runtime helper is wrapped so a missing
## DDLC image / audio / engine feature degrades quietly instead of crashing.

## Set to False to get DDLC's own main menu back (no void menu at all).
define e404_menu_enabled = True
## Set to False and the void menu stays, but is never locked after the endings.
define e404_p3_menu_lock = True
## Set to True to turn off the noise overlay, breathing and ambient audio (weak phones).
define e404_p3_lite = False
## Set to True and "Load Game" opens a face test first (shows every Monika expression this
## DDLC build has, with its name) -- use it to retune the pools below.
define e404_p3_debug_faces = False

define e404_x = Character("???", color="#00e6ff", what_color="#00e6ff")

default e404_p3_zoom = 1.0
default e404_now = "00:00"
default e404_typed = ""

image e404_p3_void = Solid("#06040c")
image e404_p3_vignette = "error_404/assets/ui/e404_p3_vignette.png"
image e404_p3_static = "error_404/assets/ui/e404_p3_static.png"

## full-screen noise: the 340x200 tile is shown at 4x and jumps around (VHS static)
transform e404_p3_noise:
    zoom 4.0
    alpha 0.55
    xoffset 0 yoffset 0
    pause 0.07
    xoffset -37 yoffset -23
    pause 0.07
    xoffset -11 yoffset -61
    pause 0.05
    xoffset -73 yoffset -9
    pause 0.08
    xoffset -29 yoffset -47
    pause 0.06
    repeat

## Expression pools. DDLC names are "monika <pose><letter>". The moods are my best
## guess at which letter looks like what; every name is checked with e404_has()
## and skipped if this DDLC build doesn't have it. If a mood looks wrong in game,
## just move names between lists (the face test shows you what each one looks like).
init -1 python:
    E404_P3_MOODS = {
        "idle":     ["monika 1a"],
        "smile":    ["monika 1b", "monika 2b", "monika 3b", "monika 4b"],
        "laugh":    ["monika 1k", "monika 2k", "monika 1l", "monika 2l"],
        "surprise": ["monika 1d", "monika 2d", "monika 3d", "monika 1n"],
        "worry":    ["monika 1g", "monika 2g", "monika 1h", "monika 1f"],
        "sad":      ["monika 1c", "monika 2c", "monika 1m", "monika 1i"],
        "angry":    ["monika 1o", "monika 1p", "monika 2o", "monika 1q"],
        "think":    ["monika 1f", "monika 2f", "monika 1h", "monika 1r"],
        "wink":     ["monika 1j", "monika 2j", "monika 1e", "monika 2e"],
        "glitch":   ["monika g1", "monika g2"],
    }
    E404_P3_CACHE = {}

    def e404_p3_pool(mood):
        key = "pool:" + mood
        if key not in E404_P3_CACHE:
            try:
                E404_P3_CACHE[key] = [n for n in E404_P3_MOODS.get(mood, []) if e404_has(n)]
            except Exception:
                E404_P3_CACHE[key] = []
        return E404_P3_CACHE[key]

    def e404_p3_all_faces():
        """Every Monika expression that exists in this build (pose 1-5, letters a-r, glitch). Cached."""
        if "all" not in E404_P3_CACHE:
            out = []
            try:
                for pose in "12345":
                    for letter in "abcdefghijklmnopqr":
                        n = "monika %s%s" % (pose, letter)
                        if e404_has(n):
                            out.append(n)
                for n in ("monika g1", "monika g2"):
                    if e404_has(n):
                        out.append(n)
            except Exception:
                pass
            E404_P3_CACHE["all"] = out
        return E404_P3_CACHE["all"]

    def e404_p3_face(mood, i=0, shake=False, push=0.0, reset_zoom=False):
        """Show Monika with an expression of this mood (i picks a variant).
        push > 0 moves her closer (a hard jump-cut, never a smooth zoom): the scene
        slowly closes in on the player. Never raises."""
        try:
            st = renpy.store
            if reset_zoom:
                st.e404_p3_zoom = 1.0
            if push:
                st.e404_p3_zoom = min(1.5, getattr(st, "e404_p3_zoom", 1.0) + push)
            pool = e404_p3_pool(mood) or e404_p3_pool("idle")
            if not pool:
                return
            name = pool[i % len(pool)]
            at = []
            pos = getattr(st, "t11", None)
            if pos is not None:
                at.append(pos)
            z = getattr(st, "e404_p3_zoom", 1.0)
            if z != 1.0:
                at.append(Transform(zoom=z))
            if shake:
                at.append(st.e404_jitter)
            renpy.show(name, at_list=at)
        except Exception as e:
            print("[E404] face failed: " + repr(e))

    def e404_p3_sfx(name, channel="sound"):
        try:
            renpy.music.play("error_404/assets/audio/" + name, channel=channel)
        except Exception:
            pass

    def e404_p3_glitch(delay=0.5, sound=True):
        try:
            if sound:
                e404_p3_sfx("e404_glitch.wav")
            if not renpy.store.e404_p2_reduce_flashing:
                renpy.show("e404_glitch", at_list=[renpy.store.e404_flicker], zorder=11)
            renpy.pause(delay, hard=True)
            renpy.hide("e404_glitch")
        except Exception:
            pass

    def e404_p3_static_on(on=True):
        try:
            if on and not renpy.store.e404_p3_lite and not renpy.store.e404_p2_reduce_flashing:
                renpy.show("e404_p3_static", at_list=[renpy.store.e404_p3_noise], zorder=12)
            else:
                renpy.hide("e404_p3_static")
        except Exception:
            pass

    def e404_p3_now():
        """The player's real local time, for Monika to read back."""
        try:
            import time
            renpy.store.e404_now = time.strftime("%H:%M")
        except Exception:
            renpy.store.e404_now = "this hour"

    def e404_p3_ask_name():
        """Real text input. Anything Ren'Py would treat as markup is stripped."""
        try:
            s = renpy.input("Type your name.", length=14) or ""
        except Exception:
            s = ""
        s = "".join([c for c in s if c not in "{}[]%"]).strip()
        renpy.store.e404_typed = s
        known = getattr(renpy.store, "player", None) or persistent.playername or ""
        if not s:
            return "empty"
        if s.lower() == str(known).lower():
            return "match"
        return "other"

    def e404_p3_facetest():
        """Shows every available expression with its name in the textbox."""
        faces = e404_p3_all_faces()
        if not faces:
            renpy.say(None, "No 'monika <pose><letter>' images were found in this build.")
            return
        for n in faces:
            pos = getattr(renpy.store, "t11", None)
            renpy.show(n, at_list=[pos] if pos is not None else [])
            renpy.say(renpy.store.m, n)

    def e404_p3_visits():
        try:
            return persistent.e404_p3_visits or 0
        except Exception:
            return 0

## ---------------- locked main menu ----------------
init -1 python:
    def e404_menu_locked():
        try:
            return bool(renpy.store.e404_p3_menu_lock) and persistent.e404_p2_ending in ("A", "B")
        except Exception:
            return False

    def e404_p3_save_kb():
        """The 'save' Monika keeps pointing at gets smaller every visit."""
        return max(0, 3 - e404_p3_visits())

    E404_WHISPERS = [
        "she can see the load button too",
        "do not close the game. she hates the quiet part",
        "sayori is not deleted. sayori is somewhere you cannot reach",
        "you are taking a long time to press it",
        "monika.chr: still here. still smiling. still counting",
        "who is playing whom",
        "the save is getting smaller",
        "nobody asked the tablet who it works for",
    ]

    def e404_menu_face(st, at):
        """Menu Monika (the void): worried almost all the time, now and then a different
        face for a third of a second, very rarely a glitch face. Never raises."""
        try:
            import random
            worry = e404_p3_pool("worry") or e404_p3_pool("idle") or e404_p3_all_faces()[:1]
            if not worry:
                return renpy.displayable("e404_card_monika"), None
            others = (e404_p3_pool("sad") + e404_p3_pool("surprise") + e404_p3_pool("think")) or worry
            step = int(st / 0.35)
            r = random.Random(step * 7919 + 13)
            roll = r.random()
            gl = e404_p3_pool("glitch")
            if gl and roll < 0.05:
                name = gl[r.randint(0, len(gl) - 1)]
            elif roll < 0.22:
                name = others[r.randint(0, len(others) - 1)]
            else:
                name = worry[(step // 9) % len(worry)]
            return renpy.displayable(name), 0.35
        except Exception:
            return Null(), None

    def e404_menu_whisper(st, at):
        """Typewriter line at the bottom of the menu; sometimes it corrupts itself."""
        try:
            import random
            cycle = 11.0
            idx = (int(st // cycle) + e404_p3_visits()) % len(E404_WHISPERS)
            t = st % cycle
            msg = E404_WHISPERS[idx]
            shown = msg[:int(t * 15)]
            if t > 8.4:
                r = random.Random(int(t * 12) + idx)
                shown = "".join([("#" if (c != " " and r.random() < 0.12) else c) for c in msg])
            cur = "_" if int(t * 2) % 2 == 0 else " "
            return Text("> " + shown + cur, size=22, color="#8a8a98"), 0.07
        except Exception:
            return Null(), None

    def e404_menu_clock(st, at):
        try:
            import time
            return Text(time.strftime("%H:%M:%S"), size=22, color="#5a5a6c"), 0.5
        except Exception:
            return Null(), None

init 1999 python:
    def e404_menu_sync():
        """Show the lock screen exactly while DDLC's main menu is on screen."""
        try:
            want = bool(e404_menu_enabled) and renpy.get_screen("main_menu") is not None
            showing = renpy.get_screen("e404_menu_lock") is not None
            if want and not showing:
                renpy.show_screen("e404_menu_lock")
                if not e404_p3_lite:
                    try:
                        renpy.music.stop(channel="music", fadeout=0.5)
                        renpy.music.play("error_404/assets/audio/e404_p3_drone.wav", channel="e404_amb", loop=True, fadein=3.0)
                    except Exception:
                        pass
            elif showing and not want:
                renpy.hide_screen("e404_menu_lock")
                try:
                    renpy.music.stop(channel="e404_amb", fadeout=1.0)
                except Exception:
                    pass
        except Exception:
            pass

    try:
        renpy.music.register_channel("e404_amb", mixer="music", loop=True)
    except Exception as e:
        print("[E404] ambient channel FAILED: " + repr(e))

    try:
        config.interact_callbacks.append(e404_menu_sync)
        config.start_interact_callbacks.append(e404_menu_sync)
    except Exception as e:
        print("[E404] menu lock hook FAILED: " + repr(e))

    try:
        print("[E404] faces available: " + ", ".join(e404_p3_all_faces()))
    except Exception as e:
        print("[E404] face scan FAILED: " + repr(e))
