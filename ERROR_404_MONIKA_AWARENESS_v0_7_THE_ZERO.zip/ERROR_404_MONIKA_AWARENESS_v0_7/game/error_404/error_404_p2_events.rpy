## ERROR 404: MONIKA AWARENESS -- PROTOTYPE 2: THE TABLET
## Helpers. Python 2 compatible (DDLC = Ren'Py 6.99). Reuses e404_has,
## e404_sprite, e404_flicker and e404_jitter from Prototype 1.

## Set to False to stop Prototype 1 from continuing into Prototype 2.
define e404_prototype2_enabled = True
## Set to True to slow the rapid background changes (photosensitivity).
define e404_p2_reduce_flashing = False

init -1 python:
    E404_P2_DDLC_BGS = ["bg club_day", "bg residential_day", "bg class_day", "bg corridor",
                        "bg club_day2", "bg house", "bg kitchen", "bg bedroom", "bg sayori_bedroom"]
    E404_P2_FALLBACK_BGS = ["e404_bg_p2_a", "e404_bg_p2_b", "e404_bg_p2_c", "e404_bg_p2_d",
                            "e404_bg_street", "e404_bg_club"]
    E404_P2_TICK = "error_404/assets/audio/e404_p2_tick.wav"

    def e404_p2_sfx(path):
        try:
            renpy.music.play(path, channel="sound")
        except Exception:
            pass

    def e404_p2_prepare():
        """Pick the backgrounds used by the scene. Real DDLC backgrounds are used
        when registered; our own fallbacks fill in so changes are always visible."""
        st = renpy.store
        chosen = None
        for c in ["bg residential_day", "bg class_day", "bg corridor"]:
            if e404_has(c):
                chosen = c
                break
        if chosen is None:
            chosen = "e404_bg_p2_a"
        final = "bg club_day" if e404_has("bg club_day") else "e404_bg_club"
        pool = [b for b in E404_P2_DDLC_BGS if e404_has(b)]
        pool = pool + E404_P2_FALLBACK_BGS   # fallbacks always appended: guarantees variety
        flips = []
        for b in pool:
            if b != chosen and b != final and b not in flips:
                flips.append(b)
        st.e404_p2_chosen = chosen
        st.e404_p2_final = final
        st.e404_p2_flips = flips
        st.e404_p2_flip_i = 0
        st.e404_p2_dim_on = False
        st.e404_p2_bg = None

    def e404_p2_show_scene(bg, shake=False):
        """Hard-set the scene: background + Monika (+ dim overlay if on).
        This is a real background change, not text."""
        st = renpy.store
        renpy.scene()
        renpy.show(bg, tag="bg")
        if e404_has("monika 1a"):
            pos = getattr(st, "t11", None)
            at = []
            if pos is not None:
                at.append(pos)
            if shake:
                at.append(st.e404_jitter)
            renpy.show("monika 1a", at_list=at)
        if getattr(st, "e404_p2_dim_on", False):
            renpy.show("e404_p2_dim", zorder=10)
        st.e404_p2_bg = bg

    def e404_p2_flash():
        if not renpy.store.e404_p2_reduce_flashing:
            renpy.show("e404_glitch", at_list=[renpy.store.e404_flicker], zorder=11)

    def e404_p2_flip(delay=0.0, glitch=False):
        """Forced change: next background from the list, instantly."""
        st = renpy.store
        flips = st.e404_p2_flips
        bg = flips[st.e404_p2_flip_i % len(flips)]
        st.e404_p2_flip_i += 1
        e404_p2_show_scene(bg)
        e404_p2_sfx(E404_P2_TICK)
        if glitch:
            e404_p2_flash()
        if delay:
            renpy.pause(delay, hard=True)

    def e404_p2_return_to_chosen(delay=0.9, glitch=True):
        """The scene briefly goes back to the background Monika selected."""
        e404_p2_show_scene(renpy.store.e404_p2_chosen)
        if glitch:
            e404_p2_flash()
        renpy.pause(delay, hard=True)

    def e404_p2_burst(delays, glitch_at=(), return_at=None):
        """Bounded series of forced changes (finite list: no runaway loop)."""
        st = renpy.store
        for i, d in enumerate(delays):
            if st.e404_p2_reduce_flashing:
                d = max(d, 0.35)
            if return_at is not None and i == return_at:
                e404_p2_show_scene(st.e404_p2_chosen)
                e404_p2_sfx(E404_P2_TICK)
                renpy.pause(d, hard=True)
            else:
                e404_p2_flip(d, glitch=(i in glitch_at))

    def e404_p2_subtle_flip(delay=0.45):
        """A short, quiet change that snaps back to the current 'wrong' scene."""
        st = renpy.store
        cur = st.e404_p2_bg
        bg = st.e404_p2_flips[st.e404_p2_flip_i % len(st.e404_p2_flips)]
        st.e404_p2_flip_i += 1
        e404_p2_show_scene(bg)
        renpy.pause(delay, hard=True)
        e404_p2_show_scene(cur)

    def e404_p2_shake():
        """Monika flinches (reuses the Prototype 1 jitter on her existing sprite)."""
        e404_p2_show_scene(renpy.store.e404_p2_bg, shake=True)
