## ERROR 404: MONIKA AWARENESS -- PROTOTYPE 2: THE TABLET
## Images, transforms and the tablet screen. All names prefixed e404_.
## UI redesign (0.5.0): clean bezel art, readable type scale, large touch buttons.

image e404_p2_dim = "error_404/assets/glitch/e404_p2_dim.png"
image e404_p2_end_a = "error_404/assets/ending/e404_p2_end_a.png"
image e404_p2_end_b = "error_404/assets/ending/e404_p2_end_b.png"
image e404_bg_p2_a = "error_404/assets/bg/e404_bg_p2_a.png"
image e404_bg_p2_b = "error_404/assets/bg/e404_bg_p2_b.png"
image e404_bg_p2_c = "error_404/assets/bg/e404_bg_p2_c.png"
image e404_bg_p2_d = "error_404/assets/bg/e404_bg_p2_d.png"

transform e404_corner:
    xpos 40
    ypos 30

transform e404_blink:
    alpha 1.0
    pause 0.7
    alpha 0.15
    pause 0.7
    repeat

## The tablet is now a small STATUS CARD in the top-left corner. It never holds buttons and
## never covers Monika's face or the textbox: choices are made with Ren'Py's own `menu:`
## (the same look as DDLC's original choices). `mode` is kept only so old calls still work.
screen e404_tablet(head="ERROR 404", l1="", l2="", l3="", mode=0):
    zorder 5

    fixed:
        xpos 16
        ypos 16
        xysize (520, 176)

        add "error_404/assets/ui/e404_p3_card.png"
        add Solid("#ff2060", xysize=(10, 10)) xpos 22 ypos 22 at e404_blink

        if len(head) <= 16:
            text head size 32 color "#ff5ad8" xpos 44 ypos 14
        else:
            text head size 23 color "#ff5ad8" xpos 44 ypos 20
        if l1:
            text l1 size 23 color "#e9e9f2" xpos 44 ypos 66
        if l2:
            text l2 size 23 color "#00e6ff" xpos 44 ypos 98
        if l3:
            text l3 size 20 color "#8a8a98" xpos 44 ypos 132
