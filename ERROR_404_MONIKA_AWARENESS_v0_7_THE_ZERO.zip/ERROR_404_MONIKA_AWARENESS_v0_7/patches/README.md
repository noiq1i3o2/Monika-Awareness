# OPTIONAL manual integration (only if the automatic hook fails)

Version 0.2.0 hooks itself in, so you normally do not need this file.

I do not ship a `.patch` file. DDLC's scripts are distributed inside compiled archives, and I had no copy of the original source to generate or test an exact diff against. A fake diff would be worse than clear instructions.

## Get an editable `script.rpy`
DDLC ships its scripts compiled (`.rpyc` inside `.rpa`). Use a DDLC mod template or decompiling tools (unrpa + unrpyc) on a **copy** of your game to get `script.rpy`. I have not verified the layout of any template, so check that it contains `script.rpy`.

## The edit
Open `script.rpy`, find `label start:`. In it, find the line that starts the first chapter:

    call ch0_main

Replace it with:

    jump e404_main

Use `jump`, not `call`. With `call`, DDLC would continue into the original chapter 1 after the mod ends.

Exact surrounding lines may differ by DDLC version. Change only that one line.

## Optional: edit the Sayori line in place instead
The mod recreates a short opening so the "error 404 : Come to the club" line is guaranteed to appear. If you would rather patch the real opening, search the decompiled `script-ch0.rpy` for Sayori's club invitation and swap in the e404 line yourself. I have not verified that location, so it is left manual.
