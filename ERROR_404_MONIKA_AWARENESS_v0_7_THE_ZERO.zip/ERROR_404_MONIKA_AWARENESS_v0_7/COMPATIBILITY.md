# Compatibility

| Target | Status |
|---|---|
| DDLC original scripts, Ren'Py 6.99.x | Designed for; Prototype 1 (0.2.0) was reported working by the user; **Prototype 2 untested** |
| Ren'Py 7/8 DDLC builds | Syntax should work; untested |
| Windows | Intended; untested by me |
| Phone launcher with Ren'Py 6.99 runtime | 0.2.0 drop-in install reported working; Prototype 2 untested |
| Monika After Story submod | Not supported (different architecture) |

Unverified assumptions: DDLC defines `s`, `m`, `mc`, transform `t11`; images `monika 1a`, `sayori 1a`, backgrounds `bg residential_day/class_day/corridor/club_day/...`. Everything except `s`, `m`, `mc` is guarded with fallbacks.
Prototype 2 engine-API risks (not run): `screen e404_tablet` syntax, `renpy.show(..., tag="bg")`, `renpy.music.play(channel="sound")`, `renpy.pause(hard=True)`, and the `namemap` start hook from Prototype 1.
