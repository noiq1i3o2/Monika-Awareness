# CHANGELOG

## 0.7.0 -- THE ZERO
- NEW: at 0 KB, LOAD GAME opens an error box with **Go Back** / **Continue Anyway**. Go Back asks "Are you sure? Every piece of data will be deleted, including backups." (Yes = reset the mod's own progress and restart; No = back to the error).
- NEW: Continue Anyway shows glitched Sayori, Yuri, Natsuki (stutter + ghost copy), one original-game line each, and no Monika.
- NEW: the walk home with nobody coming, then "Select the device you are using" (mobile or PC) with a warning; a wrong choice (checked against the real platform) inverts controls and renames the window.
- NEW: a walkable, wrapping night street (custom displayable, no images needed except the generated mask/glow/joystick): light radius around you, dying lamps, a faceless figure that only moves when you stand still, heartbeat, whispers, and a short ending ("You stopped.").
- CHANGED: grammar and tone pass on the opening (Prototype 1), the third-visit lines (the save now "just hit zero"), and the version label (V0.7).
- Internals: `error_404_p7_*.rpy` (3 files), `tools/generate_p7_assets.py`, `tests/validate_v07.py`.

# Changelog
## 0.1.0
- First prototype: five-scene sequence, original assets, static validator, Windows install guide.
## 0.2.0
- Fixed: sound effects used bare names (Ren'Py would search its audio namespace and raise an error). Now literal file paths.
- Added: automatic start hook, so no edit of DDLC's script.rpy is needed.
- Added: `[E404]` log lines for hook status; install-only ZIP.

## 0.3.0 -- Prototype 2: THE TABLET
- Added: continuation after "Now you're all mine." (background change that works, forced background changes, panic, player line, tablet, two real endings).
- Added: interactive `e404_tablet` screen (touch/mouse/keyboard), 4 fallback backgrounds, tablet art, dim overlay, 2 ending cards, 2 sounds, persistent ending flags.
- Changed: `error_404_labels.rpy` (+5 lines, join point), `error_404_screens.rpy` (version string). Everything else from Prototype 1 is byte-identical; originals in `backup_prototype_1/`.
- Added: PROJECT_MEMORY.md, STORY_CONTINUITY.md, INSTALLATION.md, TEST_REPORT.md, expanded validator.

## 0.4.0 -- Prototype 3: THE LOAD
- Fixed (0.3.0 hotfix): `e404_tablet` crashed with `NameError: mode` (screen `modal` was evaluated before parameters were bound); now a click-blocking button when `mode == 2`.
- Added: locked main menu after either ending (drawn over DDLC's menu as a modal screen; only "Load Game" is live; Sayori/Yuri/Natsuki shown as missing; Monika glitches and cycles faces). Switch: `e404_p3_menu_lock`.
- Added: "Load Game" starts `e404_p3_start` (no save is loaded): Monika discovers she has more than one face, uses ~10 expression moods, talks about the others being "unlisted, not deleted", reacts to ending A/B, and a "???" speaker intrudes. Later visits play `e404_p3_revisit`.
- Added: expression pools + `e404_p3_face()`, face test (`e404_p3_debug_faces`), `[E404] faces available:` log line.

## 0.5.0 -- Prototype 3 reworked
- UI: new tablet art (clean bezel, faint scanlines), no text/button overlap, 76 px touch buttons with hover states; new locked menu (title with chromatic split, file panel, typewriter whisper line, live clock, only LOAD GAME styled as alive).
- Creepier: Monika mostly frozen on one smile with brief face flickers in the menu; real clock time; name prompt; darkness/breathing beat; hard zoom cuts; static/glitch-face flash; 4 new ambient sounds (drone, heartbeat, static, whisper); save shrinks 3 -> 2 -> 1 KB per visit; 3rd-visit scene.
- Optimised: face list cached, all helpers fail-safe, noise is a 340x200 tile at 4x (200 KB instead of 3 MB), menu redraw only for small text, `e404_p3_lite` switch removes noise/ambient/breathing.

## 0.6.0 -- the void menu
- Locked main menu is now a black void: Monika alone, trembling, worried faces (rare other/glitch faces), three animated sweat drops, static + vignette. The tablet is the whole menu (LOAD GAME alive; New Game/Settings/Quit dead) and sits low on the screen at 80% so her face stays visible.
- All tablet screens (Prototype 2 and 3) now use the same low 80% placement.
- Sweat drop positions: `e404_sweat_a/b/c` in `error_404_p3_menu.rpy`.

## 0.6.0 (revised) -- void menu from the first launch, choices like the original
- Main menu is replaced from the very first launch: black void, worried/trembling/sweating Monika, "Doki Doki Literature Club" with "Monika Awareness" under it, "V0.6" bottom-right. New Game / Load Game / Settings / Quit work normally until an ending is reached; after that only LOAD GAME works (starts Prototype 3).
- The tablet is now a small info card in the top-left corner (no buttons), so it can't cover Monika or the textbox. The DELETE / KEEP decision is a native Ren'Py `menu:` (same look as the original game's choices).
- New switch `e404_menu_enabled` (False = DDLC's own menu). Removed unused tablet and menu-background art.
