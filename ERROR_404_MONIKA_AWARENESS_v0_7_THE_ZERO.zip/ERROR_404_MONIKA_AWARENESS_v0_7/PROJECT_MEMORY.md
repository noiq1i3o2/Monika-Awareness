# PROJECT_MEMORY.md -- ERROR 404: MONIKA AWARENESS

Give this file, STORY_CONTINUITY.md and the project folder to a future Claude conversation to continue without chat history. The code is the source of truth; this file is a map.

## Identity
- Title: ERROR 404: MONIKA AWARENESS. Current version: **0.3.0 = Prototype 2: THE TABLET** (Prototype 1 = 0.2.0, kept intact).
- Target: original Doki Doki Literature Club (Ren'Py 6.99.x, Python 2 syntax). Standalone story mod: plain `.rpy` files in `game/error_404/`. NOT a MAS submod. User confirmed the 0.2.0 drop-in install worked on their launcher (a phone launcher with a Ren'Py 6.99 runtime picker); the user also says Windows. Prototype 2 itself is untested in a real engine.
- Install = copy `game/error_404/` into DDLC's `game/`. No edit of DDLC scripts: `error_404_events.rpy` re-points the `start` label to `e404_main` after load (`renpy.game.script.namemap`, init 1999) and prints `[E404] hook OK` to log.

## Entry point and last playable scene
- New Game -> DDLC name prompt (normal) -> `start` (hooked) -> `e404_main`.
- Prototype 1 last line: Monika, `"So, was that fun? They weren't alive anyway. Now you're all mine."` in `e404_scene5_monika_returns`, then `pause 2.0` and return.
- Join point (added in Prototype 2, `error_404_labels.rpy`, inside `e404_main`): `if e404_prototype2_enabled: jump e404_p2_start` else `jump e404_end` (Prototype 1 ending card).
- Last playable scene now: Ending A or B (`e404_p2_ending_a/b`), each ends with `return` to the main menu.

## Labels
| Label | File |
|---|---|
| `e404_main` | `error_404_labels.rpy` |
| `e404_scene1_sayori` | `error_404_labels.rpy` |
| `e404_scene2_club_glitch` | `error_404_labels.rpy` |
| `e404_scene3_monika_knows` | `error_404_labels.rpy` |
| `e404_scene4_timeline_skip` | `error_404_labels.rpy` |
| `e404_scene5_monika_returns` | `error_404_labels.rpy` |
| `e404_end` | `error_404_labels.rpy` |
| `e404_p2_start` | `error_404_p2_labels.rpy` |
| `e404_p2_scene1_after_claim` | `error_404_p2_labels.rpy` |
| `e404_p2_scene2_background` | `error_404_p2_labels.rpy` |
| `e404_p2_scene3_player_speaks` | `error_404_p2_labels.rpy` |
| `e404_p2_scene4_tablet` | `error_404_p2_labels.rpy` |
| `e404_p2_choose` | `error_404_p2_labels.rpy` |
| `e404_p2_ending_a` | `error_404_p2_labels.rpy` |
| `e404_p2_ending_b` | `error_404_p2_labels.rpy` |

## Screens / transforms / images
- Screen `e404_tablet(head, l1, l2, l3, mode)`: mode 0 text only, 1 buttons shown but disabled, 2 active+modal. Returns `"delete"` / `"keep"`.
- Transforms: `e404_flicker`, `e404_jitter` (P1), `e404_corner`, `e404_blink` (P2).
- Reused from DDLC (all guarded by `e404_has`, with fallbacks): `s`, `m`, `mc`, `t11`, `bg residential_day`, `bg club_day`, `bg class_day`, `bg corridor`, `bg club_day2`, `bg house`, `bg kitchen`, `bg bedroom`, `bg sayori_bedroom`, `sayori 1a`, `monika 1a`. Only `s`, `m`, `mc` have no fallback. Which DDLC backgrounds actually exist has NOT been verified.
- Own assets: see `asset_manifest.json` (regenerate all with `python tools/generate_assets.py`; deterministic).

## Variables / persistent flags
- Defines: `e404_prototype2_enabled` (True), `e404_p2_reduce_flashing` (False), `e404_auto_hook` (True).
- Store (set at runtime, created fresh each run): `e404_p2_chosen`, `e404_p2_final`, `e404_p2_flips`, `e404_p2_flip_i`, `e404_p2_dim_on`, `e404_p2_bg`, `e404_p2_choice`.
- Persistent (new, safe for old saves because unset attributes read as None): `persistent.e404_p2_started`, `persistent.e404_p2_ending` ("A"/"B"), `persistent.e404_p2_seen_a`, `persistent.e404_p2_seen_b`. Nothing else is persisted. No `default persistent` lines.

## What Prototype 2 changed
- Added: `error_404_p2_labels.rpy`, `error_404_p2_events.rpy`, `error_404_p2_tablet.rpy`, 4 fallback backgrounds, tablet art, dim overlay, 2 ending cards, 2 sounds.
- Modified: `error_404_labels.rpy` (+5 lines at the join point), `error_404_screens.rpy` (version string only). Backup of everything original: `backup_prototype_1/` with SHA-256 of the three scripts.
- Untouched (byte-identical, checked by `tests/validate_project.py`): `error_404_events.rpy`, all Prototype 1 assets, all Prototype 1 dialogue and flow.

## Design decisions
- Forced background changes are real `renpy.scene()` + `renpy.show()` hard cuts, in finite scripted lists (no loops/timers). Monika's sprite is re-shown each time.
- Final "wrong" scene = the original clubroom plus a dark blue-tinted overlay (`e404_p2_dim`).
- Monika's fear is carried by dialogue, a one-shot flinch (`e404_jitter`) and silence, not new sprites (DDLC expression names unverified).
- Photosensitivity: the fastest burst is about 10 changes per second for roughly one second. Set `e404_p2_reduce_flashing = True` to slow it to >= 0.35 s per change and drop the glitch overlay.

## Compatibility notes / unresolved
- Never run in Ren'Py. Risks: screen-language syntax in `e404_tablet`, `renpy.show(..., tag="bg")`, `renpy.music.play(channel="sound")`, the `namemap` hook, and the guessed DDLC image names.
- DDLC's name-entry prompt always precedes the mod (it is before `start`).
- Android/MAS launcher: only the 0.2.0 drop-in install is known to have worked.
- Test results: see TEST_REPORT.md.

## Prototype 3 hook (do not resolve yet)
Who made the tablet, why it has authority over Monika, what the "secondary process" is, and whether Monika was aware before the mod.

## Prototype 3 (0.4.0) addendum
- New files: `error_404_p3_events.rpy` (face pools, `e404_x` speaker, lock logic, interact callback), `error_404_p3_menu.rpy` (screen `e404_menu_lock`, menu transforms), `error_404_p3_labels.rpy` (`e404_p3_start`, `e404_p3_revisit`, `e404_p3_face_test`).
- Menu lock = modal screen on the screens layer, shown by `config.interact_callbacks` while `main_menu` is on screen and `persistent.e404_p2_ending` in (A, B). Defines: `e404_p3_menu_lock`, `e404_p3_debug_faces`.
- Persistent: `e404_p3_visits`, `e404_p3_done`.
- Risks (not run): expression names are guessed (`monika <pose><letter>`, all guarded), `config.interact_callbacks`, `Start("e404_p3_start")` from the main menu, `renpy.displayable` in `DynamicDisplayable`.
- Prototype 3 labels: `e404_p3_start`, `e404_p3_revisit`, `e404_p3_face_test` (all in `error_404_p3_labels.rpy`).
- 0.5.0 rework: label `e404_p3_third` (3rd+ visit). New `ui/` assets and 4 ambient sounds from `tools/generate_p3_assets.py`. Tablet and menu UI redesigned. Defines: `e404_p3_lite` (no noise/ambient), `e404_p3_menu_lock`, `e404_p3_debug_faces`. Creep effects: jump-cut zoom (`e404_p3_zoom`), real clock time, `renpy.input` name prompt, darkness + breathing beat, "close the game" bait, static/glitch face flash (skipped if `e404_p2_reduce_flashing`).
- 0.6.0: menu = void + worried Monika (`e404_menu_face` uses worry/sad/surprise/think pools), sweat drops (`e404_p3_sweat.png`, transforms `e404_sweat_a/b/c`), tablet placed by `e404_tablet_low` (zoom 0.8, bottom). Removed `e404_p3_menu_bg`.
- 0.6.0 revised: void menu from first launch (`e404_menu_lock` screen in `error_404_p3_menu.rpy`; `e404_version_label = "V0.6"`; `e404_menu_enabled`). Tablet = info-only card top-left (`ui/e404_p3_card.png`); the P2 choice is `menu:` in `e404_p2_choose` (no `call screen`, no `Return` values; `e404_p2_choice` set by the menu).


## v0.7.0 addendum (THE ZERO)
- Entry: void menu LOAD GAME -> `Start("e404_p7_start")` when `e404_p3_save_kb() <= 0` (or always, via `e404_p7_test_start`).
- Labels (`error_404_p7_labels.rpy`): `e404_p7_start`, `e404_p7_error_loop`, `e404_p7_reset`, `e404_p7_continue`, `e404_p7_walk_home`.
- Screens (`error_404_p7_screens.rpy`): `e404_p7_error`, `e404_p7_confirm`, `e404_p7_device`, `e404_p7_walk` (all via `call screen` + `_return`).
- Engine (`error_404_p7_events.rpy`): `E404Walk(renpy.Displayable)` (rect-drawn world 2400x1800 that wraps, collision, keys + floating joystick, figure state machine: 2 vanishes then final, or caught when standing still), `E404P7Hold.walk` (class attribute so the displayable is never pickled), `E404Poll` action ends the screen.
- Persistent: `e404_p7_seen`, `e404_p7_finished`. Reset clears only e404_* flags. Variables: `e404_device`, `e404_p7_invert`.
- Verified: syntax of all python blocks, headless simulation of the walk logic with stubbed Ren'Py (movement, collision, wrap, joystick, inversion, figure/ending). NOT run in a real Ren'Py. Risks: `call screen` + custom displayable in 6.99, `renpy.display.interface.set_window_caption`, `renpy.full_restart()`, channel registration, performance of per-frame rect blits on weak phones (set `e404_p7_calm`/`e404_p3_lite`).
- Next (v0.8 hook): what the figure is; what stands where Sayori used to run from.
