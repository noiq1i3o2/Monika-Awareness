"""Static checks for ERROR 404: MONIKA AWARENESS v0.7. NOT a substitute for running Ren'Py.
Usage: python tests/validate_v07.py [project_root]"""
import os, re, sys, py_compile, tempfile
root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(root, "game", "error_404")
ok_all = []
def check(name, ok, detail=""):
    ok_all.append(bool(ok)); print(("PASS  " if ok else "FAIL  ") + name + ((" -- " + str(detail)) if (detail and not ok) else ""))
rd = lambda p: open(p, encoding="utf-8").read()
files = sorted(f for f in os.listdir(G) if f.endswith(".rpy"))
src = {f: rd(os.path.join(G, f)) for f in files}
allsrc = "\n".join(src.values())
for f in ("error_404_p7_events.rpy", "error_404_p7_labels.rpy", "error_404_p7_screens.rpy"):
    check("file present: " + f, f in src)
lab = src["error_404_p7_labels.rpy"]; scr = src["error_404_p7_screens.rpy"]; ev = src["error_404_p7_events.rpy"]

# labels / jumps / screens
labels = set(re.findall(r"^label (\w+):", allsrc, re.M))
jumps = set(re.findall(r"\bjump (\w+)", lab)) | set(re.findall(r"\bStart\(\"(\w+)\"\)", allsrc))
check("every jump / Start() target exists", all(j in labels for j in jumps), sorted(j for j in jumps if j not in labels))
screens = set(re.findall(r"^screen (\w+)", allsrc, re.M))
cs = set(re.findall(r"^\s*call screen (\w+)", lab, re.M))
check("every `call screen` target exists", cs <= screens, cs - screens)

# images / audio referenced exist on disk
paths = set(re.findall(r"[\"'](error_404/assets/[\w/\.\-]+)[\"']", allsrc))
paths |= set("error_404/assets/audio/" + n for n in re.findall(r"e404_p3_sfx\(\"([\w\.]+)\"\)", lab))
missing = [p for p in paths if not os.path.exists(os.path.join(root, "game", p))]
check("every referenced asset file exists", not missing, missing)

# story requirements
need = ["Go Back", "Continue Anyway", "Are you sure", "Every piece of data will be deleted", "including backups",
        "Select the device you are using", "mobile or PC", "WARNING", "completely alter", "Yes", "No"]
blob = scr + lab
check("required UI texts present", all(n.lower() in blob.lower() for n in need), [n for n in need if n.lower() not in blob.lower()])
order = [lab.find(k) for k in ("e404_p7_show_glitched(\"sayori", "e404_p7_show_glitched(\"yuri", "e404_p7_show_glitched(\"natsuki")]
check("glitched Sayori -> Yuri -> Natsuki in order", all(o > 0 for o in order) and order == sorted(order), order)
check("Monika is never shown in the glitched trio", "monika" not in lab[lab.find("label e404_p7_continue"):lab.find("label e404_p7_walk_home")].lower().replace("monika awareness", ""))
check("walk home: nobody comes + device choice before the walk", lab.find("Nobody comes") < lab.find("e404_p7_device") < lab.find("e404_p7_start_walk"))
check("'No' on the confirm returns to the error", "jump e404_p7_error_loop" in lab)
check("'Yes' resets via e404_p7_reset_game()", "e404_p7_reset_game()" in lab)
check("menu: LOAD GAME starts v0.7 at 0 KB", "Start(\"e404_p7_start\") if e404_p3_save_kb() <= 0" in src["error_404_p3_menu.rpy"])
check("WASD + arrow keys + virtual joystick in the walk", all(k in ev for k in ("pygame.K_w", "pygame.K_a", "pygame.K_s", "pygame.K_d", "joy_vec", "MOUSEBUTTONDOWN")))

# safety: nothing outside this mod is deleted
bad = re.search(r"os\.remove|unlink|rmtree|shutil|os\.rename|os\.system|subprocess|urllib|socket|requests|\bopen\(|camera|microphone|renpy\.quit|renpy\.exit", allsrc)
check("no file deletion / network / device access (only full_restart after the in-game reset)", not bad, bad.group(0) if bad else "")
check("reset only touches e404_* persistent flags", set(re.findall(r'"(e404_\w+)"', ev[ev.find("def e404_p7_reset_game"):ev.find("## ---------------- device choice")])) >= {"e404_p3_visits"} and "persistent." not in ev[ev.find("def e404_p7_reset_game"):ev.find("## ---------------- device choice")].replace("setattr(persistent", ""))

# python blocks compile (py3 syntax check of py2-compatible code)
blocks = []
for f, text in src.items():
    cur = None
    for line in text.split("\n"):
        if re.match(r"^(init\s+-?\d*\s*)?python:", line): cur = []; blocks.append(cur); continue
        if cur is not None:
            if line.startswith("    ") or not line.strip(): cur.append(line[4:] if line.startswith("    ") else line)
            else: cur = None
errs = []
for i, b in enumerate(blocks):
    tf = tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8"); tf.write("\n".join(b)); tf.close()
    try: py_compile.compile(tf.name, doraise=True)
    except Exception as e: errs.append((i, str(e)[:120]))
    os.unlink(tf.name)
check("all python blocks compile (%d blocks)" % len(blocks), not errs, errs)
check("no f-strings / print statements / nonlocal (Python 2 safe)", not re.search(r"\bf\"|\bf'|\bnonlocal\b|^\s*print [^(]", allsrc, re.M))
tabs = [f for f, t in src.items() if "\t" in t]
check("no tab characters", not tabs, tabs)
print("\n%d/%d checks passed\nNOTE: static only. No Ren'Py engine, DDLC, Windows or Android run was performed." % (sum(ok_all), len(ok_all)))
sys.exit(0 if all(ok_all) else 1)
