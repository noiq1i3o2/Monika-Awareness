# Manual test checklist (run in real DDLC; nothing below has been run by me)

## Prototype 1 still intact
- [ ] Title card appears; log has `[E404] ... 0.3.0 (Prototype 2) loaded` and `hook OK`
- [ ] Sayori says "error 404 : Come to the club"; player asks if she is okay; soft flicker
- [ ] Club entry glitch every time; Monika's awareness speech (8 lines)
- [ ] Montage: Sayori, Yuri, Natsuki, Monika cards in order
- [ ] "So, was that fun? They weren't alive anyway. Now you're all mine."

## Prototype 2
- [ ] Continues right after that line (no title card, no restart)
- [ ] Monika changes the background and it visibly changes (dissolve)
- [ ] Background then changes by itself, repeatedly, getting faster; one return to her background
- [ ] Panic lines appear in order; rapid changes stop; silence; dark familiar clubroom
- [ ] Player line "Monika... what did you do?" appears
- [ ] Tablet appears (glitch + sound); "ERROR 404 / SUBJECT DETECTED: MONIKA / SELECT ACTION"
- [ ] Both buttons readable; neither pre-selected; tapping them during Monika's lines does nothing
- [ ] After her last line the buttons work (touch/mouse/keyboard); no timeout, game not stuck
- [ ] DELETE -> Ending A only; KEEP -> Ending B only; double tap does not double-trigger
- [ ] Both endings return to the main menu; New Game starts again normally
- [ ] Old saves still load; no files changed or deleted
- [ ] `e404_p2_reduce_flashing = True` slows the changes
- [ ] Set `e404_prototype2_enabled = False`: Prototype 1 ends with its original card


## v0.7 manual checks
- [ ] Menu shows V0.7; after 3 LOAD GAME visits the save line reads 0 KB
- [ ] LOAD GAME at 0 KB -> error box with Go Back / Continue Anyway
- [ ] Go Back -> "Are you sure?" -> No returns to the error box
- [ ] Go Back -> Yes -> reset text, game restarts, menu is normal again
- [ ] Continue Anyway -> Sayori, Yuri, Natsuki glitched with one line each; no Monika; empty void beat
- [ ] Walk home: nobody comes; device choice shows the warning
- [ ] PC: W A S D and arrows move; Mobile: drag to move; walls block you
- [ ] Wrong device choice: controls inverted, window title changes, text says so
- [ ] Figure appears at the edge of the light, vanishes twice when approached, third time ends; standing still also ends
- [ ] Ending card, then back to the menu with no crash
