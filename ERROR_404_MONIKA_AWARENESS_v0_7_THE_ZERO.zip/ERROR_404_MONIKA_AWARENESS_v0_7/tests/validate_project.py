"""Static validation for ERROR 404: MONIKA AWARENESS (Prototype 1 + Prototype 2).
NOT a substitute for running Ren'Py. Usage: python tests/validate_project.py [project_root]"""
import os, re, sys, json, hashlib

root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
results = []
def check(name, ok, detail=""):
    ok = bool(ok)
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + ((" -- " + str(detail)) if detail else ""))
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def rd(p): return open(p, encoding="utf-8").read()

G = os.path.join(root, "game", "error_404")
BK = os.path.join(root, "backup_prototype_1", "game", "error_404")
files = sorted(f for f in os.listdir(G) if f.endswith(".rpy"))
expected = ["error_404_events.rpy", "error_404_labels.rpy", "error_404_p2_events.rpy", "error_404_p2_labels.rpy", "error_404_p2_tablet.rpy", "error_404_p3_events.rpy", "error_404_p3_labels.rpy", "error_404_p3_menu.rpy", "error_404_screens.rpy"]
check("rpy files present (3 Prototype 1 + 3 Prototype 2 + 3 Prototype 3)", files == expected, files)
src = {f: rd(os.path.join(G, f)) for f in files}
allsrc = "\n".join(src[f] for f in files)
p1 = src["error_404_labels.rpy"]; p2 = src["error_404_p2_labels.rpy"]; ev = src["error_404_events.rpy"]
tab = src["error_404_p2_tablet.rpy"]; p2ev = src["error_404_p2_events.rpy"]

required = ["README.md", "INSTALLATION.md", "COMPATIBILITY.md", "CHANGELOG.md", "LICENSES_AND_ASSETS.md", "PROJECT_MEMORY.md",
            "STORY_CONTINUITY.md", "TEST_REPORT.md", "patches/README.md", "tests/test_checklist.md", "tools/generate_assets.py", "asset_manifest.json"]
miss = [r for r in required if not os.path.exists(os.path.join(root, r))]
check("required files exist", not miss, miss)

# ---------- backup / preservation of Prototype 1 ----------
check("backup of Prototype 1 present", os.path.isdir(BK) and all(os.path.exists(os.path.join(BK, f)) for f in ["error_404_events.rpy", "error_404_labels.rpy", "error_404_screens.rpy"]))
check("error_404_events.rpy (hook) byte-identical to Prototype 1", sha(os.path.join(G, "error_404_events.rpy")) == sha(os.path.join(BK, "error_404_events.rpy")))
import difflib
def changed(a, b):
    return [l for l in difflib.unified_diff(rd(a).split("\n"), rd(b).split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
dl = changed(os.path.join(BK, "error_404_labels.rpy"), os.path.join(G, "error_404_labels.rpy"))
check("Prototype 1 labels: only additions, 5 lines (Prototype 2 join)", len(dl) == 5 and all(l.startswith("+") for l in dl), dl)
ds = changed(os.path.join(BK, "error_404_screens.rpy"), os.path.join(G, "error_404_screens.rpy"))
check("Prototype 1 screens file: only the version string changed", len(ds) == 2 and "e404_VERSION" in ds[0] + ds[1], ds)
p1_assets = [os.path.relpath(os.path.join(d, f), os.path.join(BK, "assets")) for d, _, fs in os.walk(os.path.join(BK, "assets")) for f in fs]
check("all Prototype 1 assets present and byte-identical", p1_assets and all(os.path.exists(os.path.join(G, "assets", a)) and sha(os.path.join(G, "assets", a)) == sha(os.path.join(BK, "assets", a)) for a in p1_assets), len(p1_assets))

# ---------- labels / references ----------
labels = re.findall(r"^label\s+(\w+)", allsrc, re.M)
check("no duplicate labels", len(labels) == len(set(labels)), sorted(set(l for l in labels if labels.count(l) > 1)))
check("all labels use e404_ prefix", all(l.startswith("e404_") for l in labels))
refs = re.findall(r"^\s*(?:jump|call)\s+(\w+)\s*$", allsrc, re.M)
check("every jump/call targets a defined e404_ label (no original-game labels)", all(r in labels for r in refs), [r for r in refs if r not in labels])
screens = re.findall(r"^screen\s+(\w+)", allsrc, re.M)
check("screen names unique and prefixed", len(screens) == len(set(screens)) and all(s.startswith("e404_") for s in screens), screens)
scr_use = re.findall(r"(?:show|call) screen (\w+)", allsrc)
check("every used screen is defined", all(s in screens for s in scr_use), scr_use[:3])
defs = set(re.findall(r"^\s*def\s+(\w+)\(", allsrc, re.M))
calls = set(re.findall(r"\$\s*(e404_\w+)\(", allsrc))
check("every helper called with $ is defined", calls <= defs, calls - defs)
check("helper/def names prefixed e404_ or E404_", all(d.startswith("e404_") for d in defs), [d for d in defs if not d.startswith("e404_")])

# ---------- images / audio ----------
defined = set(re.findall(r"^image\s+(e404_\w+)\s*=", allsrc, re.M))
used = set(re.findall(r"^\s*(?:show|scene)\s+(e404_\w+)", allsrc, re.M)) | set(re.findall(r"[\"\x27](e404_\w+)[\"\x27]", allsrc))
check("every shown e404_ image is defined", set(re.findall(r"^\s*(?:show|scene)\s+(e404_\w+)", allsrc, re.M)) <= defined | set(screens))
check("every defined image is used", defined <= used, defined - used)
paths = re.findall(r"\"(error_404/assets/[^\"]+)\"", allsrc)
check("every asset path in scripts exists", paths and all(os.path.exists(os.path.join(root, "game", p)) for p in paths), [p for p in paths if not os.path.exists(os.path.join(root, "game", p))])
check("no bare-name audio", not re.findall(r"^\s*play\s+\w+\s+([A-Za-z_]\w*)", allsrc, re.M))
check("string-referenced bg fallbacks are defined images", set(re.findall(r"\"(e404_bg_\w+)\"", allsrc)) <= defined, set(re.findall(r"\"(e404_bg_\w+)\"", allsrc)) - defined)

# ---------- Prototype 1 story (must still be intact) ----------
beats = ["s \"error 404 : Come to the club\"", "mc \"Sayori, are you doing okay?\"", "Monika Awareness", "always have awareness", "keep it a secret",
         "bring me back using other mods", "Promise?", "you already know what happens after this", "Let's make it early.",
         "e404_card_sayori", "e404_card_yuri", "e404_card_natsuki", "e404_card_monika", "So, was that fun? They weren't alive anyway. Now you're all mine."]
pos = [p1.find(b) for b in beats]
check("Prototype 1: all story beats present, in order", all(x >= 0 for x in pos) and pos == sorted(pos), [b for b, x in zip(beats, pos) if x < 0])
order = ["call e404_scene1_sayori", "call e404_scene2_club_glitch", "call e404_scene3_monika_knows", "call e404_scene4_timeline_skip", "call e404_scene5_monika_returns", "jump e404_p2_start", "jump e404_end"]
idx = [p1.find(o) for o in order]
check("main flow: scenes 1-5 -> Prototype 2 start (e404_end kept as fallback)", all(i >= 0 for i in idx) and idx == sorted(idx))
check("Prototype 1 ending card label e404_end still present", "label e404_end:" in p1)
check("Prototype 2 reached only after Monika's final line", p1.find("Now you're all mine.") < p1.find("jump e404_p2_start"))

# ---------- Prototype 2 story order ----------
order2 = ["call e404_p2_scene1_after_claim", "call e404_p2_scene2_background", "call e404_p2_scene3_player_speaks", "jump e404_p2_scene4_tablet"]
i2 = [p2.find(o) for o in order2]
check("Prototype 2 flow order: scene1 -> 2 -> 3 -> tablet", all(i >= 0 for i in i2) and i2 == sorted(i2))
beats2 = ["There. Much better.", "Just us.", "Don't tell me you were actually attached to them.", "e404_p2_show_scene(e404_p2_chosen)", "There we go!",
          "Hm?", "Did I just--", "Okay. No, that's not right.", "Stop that.", "I didn't do that.", "Wait. Wait, wait, wait.", "Why isn't it listening?",
          "STOP CHANGING IT!", "That wasn't me.", "You're seeing that too, right?", "mc \"Monika... what did you do?\"", "I didn't do anything!",
          "Please tell me you saw that.", "show screen e404_tablet(\"ERROR 404\", \"SUBJECT DETECTED: MONIKA\"", "SELECT ACTION", "Player, don't touch it.",
          "it knows I'm here.", "label e404_p2_choose"]
p2pos = [p2.find(b) for b in beats2]
check("Prototype 2: all beats present, in the required narrative order", all(x >= 0 for x in p2pos) and p2pos == sorted(p2pos), [b for b, x in zip(beats2, p2pos) if x < 0])
first_flip = p2.find("$ e404_p2_flip()")
check("Monika's own background change happens BEFORE the first forced change", p2.find("e404_p2_show_scene(e404_p2_chosen)") < first_flip)
n_flip = len(re.findall(r"\$ e404_p2_flip\(", p2)); burst = re.findall(r"e404_p2_burst\(\[([^\]]*)\]", p2); n_burst = sum(len(b.split(",")) for b in burst)
check("at least 8 forced background changes, getting faster", n_flip + n_burst >= 8 and len(burst) == 2, (n_flip, n_burst))
bd = [[float(x) for x in b.split(",")] for b in burst]
check("burst delays shrink over time and are finite lists", all(d == sorted(d, reverse=True) for d in bd))
check("changes are real (renpy.scene + renpy.show), not text", "renpy.scene()" in p2ev and "renpy.show(bg, tag=\"bg\")" in p2ev)
check("no while/forever loops in Prototype 2 helpers", not re.search(r"\bwhile\b|\brepeat\b(?!\n)", re.sub(r"transform e404_blink:[\s\S]*?repeat", "", p2ev + p2)))
check("flash reduction switch exists", "e404_p2_reduce_flashing" in p2ev)

# ---------- tablet & choices ----------
for t in ["ERROR 404", "SUBJECT DETECTED: MONIKA", "SELECT ACTION", "DELETE MONIKA", "KEEP MONIKA"]:
    check("tablet/choice text present: " + t, t in p2 + tab)
check("tablet is info-only (no buttons, no modal, no call screen)", "textbutton" not in tab and "modal" not in tab.replace("NOTE", "") and "call screen e404_tablet" not in p2)
check("tablet card is in the top-left corner (cannot cover textbox or Monika)", "xpos 16" in tab and "ypos 16" in tab)
check("choice is a native menu with both options, no timer", re.search(r"menu:\n\s+\"DELETE MONIKA\":", p2) and re.search(r"\"KEEP MONIKA\":", p2) and not re.search(r"timer|timeout", tab))
check("choice routed: delete -> ending A, otherwise (keep) -> ending B", re.search(r"== \"delete\":\n\s+jump e404_p2_ending_a", p2) and "jump e404_p2_ending_b" in p2)
textlines = [l for l in allsrc.split("\n") if not re.match(r"^\s*\"\w+\":\s*\[", l) and re.match(r"^\s*(m|s|mc|text|textbutton|show text)?\s*\"", l) or re.match(r"^\s*(text|textbutton|show text)\s", l)]
badbr = [l.strip()[:60] for l in textlines if re.search(r"(?<!\[)\[(?!\[)(?!player\])(?!e404_\w+(?:\(\))?\])", l)]
check("no unescaped [ in say/text/textbutton strings (Ren'Py would try to interpolate it)", not badbr, badbr[:3])

# ---------- endings ----------
def strip_trailing_comments(t):
    ls = t.rstrip().split("\n")
    while ls and (ls[-1].strip().startswith("#") or not ls[-1].strip()):
        ls.pop()
    return "\n".join(ls)
ea = strip_trailing_comments(p2.split("label e404_p2_ending_a:")[1].split("label e404_p2_ending_b:")[0])
eb = strip_trailing_comments(p2.split("label e404_p2_ending_b:")[1])
for t in ["DELETE MONIKA", "REQUEST ACCEPTED", "PROCESSING...", "...You chose that?", "Player, wait!", "You're not deleting me, are you?", "Or is that exactly what you want?", "MONIKA: DELETION REQUESTED", "STATUS: UNKNOWN", "e404_p2_end_a"]:
    check("Ending A has: " + t, t in ea)
for t in ["KEEP MONIKA", "REQUEST ACCEPTED", "...You kept me?", "I think I will.", "...It's still here.", "SUBJECT RETAINED", "SECONDARY PROCESS DETECTED", "SOURCE: UNKNOWN", "There's something else in here.", "e404_p2_end_b"]:
    check("Ending B has: " + t, t in eb)
check("endings are distinct (no shared jumps, no cross content)", "ending_b" not in ea and "ending_a" not in eb and "SECONDARY PROCESS" not in ea and "DELETION REQUESTED" not in eb)
check("each ending sets its own persistent flag; none writes the other", "persistent.e404_p2_ending = \"A\"" in ea and "persistent.e404_p2_ending = \"B\"" in eb and "\"B\"" not in ea and "\"A\"" not in eb)
check("both endings finish with return (-> main menu), no loop to start", ea.rstrip().endswith("return") and eb.rstrip().endswith("return") and "e404_p2_start" not in ea + eb and "jump start" not in p2)
check("persistent writes use new e404_p2_ names only; no `default persistent` (old saves safe)", set(re.findall(r"persistent\.(\w+)", p2)) <= {"e404_p2_started", "e404_p2_ending", "e404_p2_seen_a", "e404_p2_seen_b"} and "default persistent" not in allsrc)
check("no destructive / network / device access", not re.search(r"os\.remove|unlink|rmtree|shutil|os\.rename|os\.system|subprocess|urllib|socket|requests|\bopen\(|camera|microphone|renpy\.quit|renpy\.exit|full_restart", allsrc))
check("hook still present and untouched", "names[\"start\"] = names[\"e404_main\"]" in ev and "init 1999 python" in ev)

# ---------- syntax heuristics ----------
bad = []
for f, text in src.items():
    for n, line in enumerate(text.split("\n"), 1):
        if "\t" in line: bad.append("%s:%d tab" % (f, n))
        if line.strip() and (len(line) - len(line.lstrip(" "))) % 4: bad.append("%s:%d indent" % (f, n))
        if re.search(r"\bf\"|\bf\x27", line): bad.append("%s:%d f-string (py2)" % (f, n))
        if re.match(r"\s*(m|s|mc)\s+\"", line) and len(re.findall(r"(?<!\\)\"", line)) % 2: bad.append("%s:%d quotes" % (f, n))
        if line.count("(") != line.count(")") and not line.rstrip().endswith((",", "(", "\\")) and "#" not in line and "\"" not in line: bad.append("%s:%d parens" % (f, n))
check("indentation/tabs/quotes/py2 syntax/parens (heuristic)", not bad, bad[:6])
import ast
pyblocks = []
for f, text in src.items():
    lines = text.split("\n"); i = 0
    while i < len(lines):
        if re.match(r"^init(\s+-?\d+)?\s+python\s*:\s*$", lines[i]):
            j = i + 1; blk = []
            while j < len(lines) and (lines[j].startswith("    ") or not lines[j].strip()):
                blk.append(lines[j][4:]); j += 1
            pyblocks.append((f, "\n".join(blk))); i = j
        else: i += 1
errs = []
for f, b in pyblocks:
    try: ast.parse(b.replace("print(", "print_("))
    except SyntaxError as e: errs.append("%s: %s line %s" % (f, e.msg, e.lineno))
check("embedded `init python` blocks parse as valid Python (%d blocks)" % len(pyblocks), pyblocks and not errs, errs)

# ---------- manifest / docs / packaging ----------
man = json.load(open(os.path.join(root, "asset_manifest.json")))
mp = sorted(a["path"] for a in man["assets"])
on_disk = sorted(os.path.relpath(os.path.join(d, f), root).replace(os.sep, "/") for d, _, fs in os.walk(os.path.join(G, "assets")) for f in fs)
check("manifest matches assets on disk", mp == on_disk, set(mp) ^ set(on_disk))
inst = rd(os.path.join(root, "INSTALLATION.md"))
cited = [p for p in re.findall(r"`(game/[^`]+)`", inst) if p.count("/") >= 2 and "*" not in p]
check("INSTALLATION.md paths exist in the archive", all(os.path.exists(os.path.join(root, p.rstrip("/"))) for p in cited), [p for p in cited if not os.path.exists(os.path.join(root, p.rstrip("/")))])
mem = rd(os.path.join(root, "PROJECT_MEMORY.md")) + rd(os.path.join(root, "STORY_CONTINUITY.md"))
check("PROJECT_MEMORY/STORY_CONTINUITY mention every label", all(l in mem for l in labels), [l for l in labels if l not in mem])
for d, _, fs in os.walk(root):
    for f in fs:
        if f.lower().endswith((".rpyc", ".rpa", ".exe", ".dll", ".bat", ".ps1", ".sh")): check("no compiled/executable payload", False, f)
total = sum(os.path.getsize(os.path.join(d, f)) for d, _, fs in os.walk(root) for f in fs)
check("package size under 2 MB", total < 2000000, "%d bytes" % total)
print("\n%d/%d checks passed" % (sum(results), len(results)))
print("NOTE: static only. No Ren'Py engine, DDLC, Windows or Android run was performed.")
sys.exit(0 if all(results) else 1)
