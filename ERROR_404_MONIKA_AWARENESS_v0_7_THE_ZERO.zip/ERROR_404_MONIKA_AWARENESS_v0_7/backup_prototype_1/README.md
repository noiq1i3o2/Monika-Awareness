# ERROR 404: MONIKA AWARENESS (prototype 0.2.0)

A short fan-made Doki Doki Literature Club horror sequence for **DDLC (Ren'Py 6.99)**.

Flow: Sayori's "error 404" line -> club-entry glitch -> Monika's awareness speech -> corrupted timeline-skip montage -> "Now you're all mine." -> deliberate ending (back to main menu).

## What is in this ZIP
- `game/error_404/` - the mod: 3 `.rpy` scripts + original generated assets (title, glitch overlay, 4 montage cards, final overlay, 2 fallback backgrounds, 2 sound effects).
- `patches/README.md` - optional manual route if the automatic hook fails.
- `INSTALL_WINDOWS.md` - step-by-step install (drop-in, no script edit).
- `COMPATIBILITY.md`, `CHANGELOG.md`, `LICENSES_AND_ASSETS.md`
- `tests/` - manual checklist + `validate_project.py` (static checks).
- `tools/generate_assets.py` - regenerates every asset (Pillow + numpy).

## What it does NOT do
- It does not include DDLC, its sprites, backgrounds or music. It reuses them from your own install when present, and falls back to its own simple art when not.
- It does not touch your files, camera, mic or anything outside the game. Monika's "awareness" is only authored dialogue.
- It ends after Monika's final line (a prototype stopping point). It does not continue into the original chapters.
- Android / MAS Launcher: **untested**. It should work wherever you can put files in the game's `game/` folder.

## Honest status
Statically validated only. It has **not been run in Ren'Py or DDLC**. See `COMPATIBILITY.md`.
