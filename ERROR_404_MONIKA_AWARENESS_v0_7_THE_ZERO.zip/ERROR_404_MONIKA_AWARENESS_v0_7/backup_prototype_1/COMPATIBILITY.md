# Compatibility

| Target | Status |
|---|---|
| DDLC original scripts | Designed for; **untested** |
| Ren'Py 6.99.x (DDLC's engine) | Python 2 compatible syntax; **untested** |
| Ren'Py 7/8 based DDLC releases | Syntax should work; **untested** |
| Monika After Story (submod) | **Not supported** |
| Android phone launcher (Ren'Py 6.99 runtime) | Should work if `game/` is writable/loadable; **untested** |

Assumptions about the original game (not verified here): characters `s`, `m`, `mc` exist; `t11` transform, backgrounds `bg residential_day`, `bg club_day`, and sprites `sayori 1a`, `monika 1a` may exist. All except `s`, `m`, `mc` have fallbacks.

Static checks run: see `tests/validate_project.py`. No Ren'Py engine was available, so no engine run was done.

The automatic hook relies on `renpy.game.script.namemap`, an internal Ren'Py structure. It is wrapped in try/except and logs `[E404] hook OK/FAILED`. It has not been run against a real engine.
