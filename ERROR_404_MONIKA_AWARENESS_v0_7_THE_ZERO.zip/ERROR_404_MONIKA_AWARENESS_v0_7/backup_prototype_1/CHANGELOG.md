# Changelog
## 0.1.0
- First prototype: five-scene sequence, original assets, static validator, Windows install guide.
## 0.2.0
- Fixed: sound effects used bare names (Ren'Py would search its audio namespace and raise an error). Now literal file paths.
- Added: automatic start hook, so no edit of DDLC's script.rpy is needed.
- Added: `[E404]` log lines for hook status; install-only ZIP.
