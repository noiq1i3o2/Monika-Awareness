## ERROR 404: MONIKA AWARENESS -- helpers, transitions, effects
## Uses Python 2 compatible syntax (DDLC ships Ren'Py 6.99.x).

define e404_cut = Fade(0.1, 0.0, 0.3)

# Short, restrained flicker: one pass, ~0.3s, ends fully transparent.
transform e404_flicker:
    alpha 0.0
    linear 0.05 alpha 0.8
    linear 0.05 alpha 0.2
    linear 0.08 alpha 0.6
    linear 0.15 alpha 0.0

transform e404_jitter:
    xoffset 0
    linear 0.04 xoffset 6
    linear 0.04 xoffset -5
    linear 0.04 xoffset 0

init -1 python:
    def e404_has(name):
        """True if an image with this name is registered (never raises)."""
        try:
            if renpy.get_registered_image(name) is not None:
                return True
        except Exception:
            pass
        try:
            return bool(renpy.has_image(name))
        except Exception:
            return False

    def e404_bg(name, fallback):
        """Show a DDLC background if present, otherwise our own fallback."""
        renpy.scene()
        renpy.show(name if e404_has(name) else fallback)

    def e404_sprite(name):
        """Show a DDLC sprite if present; silently skip it otherwise."""
        if e404_has(name):
            pos = getattr(renpy.store, "t11", None)
            if pos is not None:
                renpy.show(name, at_list=[pos])
            else:
                renpy.show(name)

    def e404_prepare_names():
        """Make sure the name variables used by dialogue exist."""
        st = renpy.store
        st.s_name = "Sayori"
        st.m_name = "Monika"
        if getattr(st, "player", None) is None:
            st.player = persistent.playername or "Player"

## ---------------------------------------------------------------
## AUTOMATIC HOOK (no edit of DDLC scripts needed)
## After every script is loaded, point the label "start" at e404_main.
## DDLC's New Game button jumps to "start", so it now runs the mod.
## Set e404_auto_hook to False to disable (then use patches/README.md).
## Everything is wrapped in try/except: on failure the game runs normally
## and the reason is written to log.txt / the console.
## ---------------------------------------------------------------
define e404_auto_hook = True

init 1999 python:
    def e404_install_hook():
        if not e404_auto_hook:
            print("[E404] auto hook disabled")
            return
        try:
            names = renpy.game.script.namemap
            if "e404_main" not in names:
                print("[E404] hook FAILED: label e404_main not found")
                return
            if "start" not in names:
                print("[E404] hook FAILED: label start not found")
                return
            names["e404_original_start"] = names["start"]
            names["start"] = names["e404_main"]
            print("[E404] hook OK: New Game now runs e404_main")
        except Exception as e:
            print("[E404] hook FAILED: " + repr(e))

    e404_install_hook()
