## ERROR 404: MONIKA AWARENESS -- image / sound definitions
## Every name is prefixed e404_ so nothing collides with DDLC.
## Paths are relative to the game/ folder.

init -1 python:
    e404_VERSION = "0.2.0"
    # Shows up in log.txt so you can confirm the mod files were loaded.
    print("[E404] ERROR 404: MONIKA AWARENESS " + e404_VERSION + " loaded")

image e404_title = "error_404/assets/title/e404_title.png"
image e404_glitch = "error_404/assets/glitch/e404_glitch_overlay.png"
image e404_final = "error_404/assets/glitch/e404_final_overlay.png"
image e404_card_sayori = "error_404/assets/montage/e404_card_sayori.png"
image e404_card_yuri = "error_404/assets/montage/e404_card_yuri.png"
image e404_card_natsuki = "error_404/assets/montage/e404_card_natsuki.png"
image e404_card_monika = "error_404/assets/montage/e404_card_monika.png"
image e404_bg_club = "error_404/assets/bg/e404_bg_club_fallback.png"
image e404_bg_street = "error_404/assets/bg/e404_bg_street_fallback.png"

