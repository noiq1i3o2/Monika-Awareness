# Install

Use **E404_INSTALL.zip** (it contains only `game/error_404/`). The full ZIP is the same mod plus docs and tools.

1. **Back up first.** Copy your whole DDLC folder. Never overwrite or delete your original install. Mod a copy.
2. Extract `E404_INSTALL.zip` into your DDLC copy's main folder (the one that already contains `game/`). You should end up with `game/error_404/error_404_labels.rpy`. If your file manager made an extra wrapper folder, move `error_404` so it sits directly inside `game/`.
3. Launch the game and press **New Game**. No edit of `script.rpy` is needed: the mod redirects DDLC's `start` label by itself.

## How to tell it loaded
- New Game shows the "ERROR 404 / MONIKA AWARENESS" title card.
- `log.txt` or `console` output contains `[E404] ... 0.2.0 loaded` and `[E404] hook OK`.
- If you see `[E404] hook FAILED`, send me that line.

## Troubleshooting
- Normal intro plays and no `[E404] loaded` line: the folder is in the wrong place (it must be `game/error_404/`), or the launcher is not running the game folder you edited.
- `loaded` but `hook FAILED`: use the manual route in `patches/README.md` (needs an editable `script.rpy`).
- Error screen: send the text or a screenshot (also `traceback.txt`).
- No sprites or backgrounds: the mod fell back to its own art. Dialogue still works.
- Undo: delete `game/error_404/`. Nothing else was changed.
