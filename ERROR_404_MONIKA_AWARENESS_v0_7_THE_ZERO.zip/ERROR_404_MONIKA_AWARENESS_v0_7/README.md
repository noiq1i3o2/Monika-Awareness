# ERROR 404: MONIKA AWARENESS -- v0.7 "THE ZERO"

Fan-made DDLC horror mod. v0.7 adds the scene that follows the save reaching **0 KB**: an error box (Go Back / Continue Anyway), glitched Sayori, Yuri and Natsuki (no Monika), then the walk home with nobody running up to you, a mobile/PC choice, and a street you can actually walk (WASD, arrow keys, or a touch joystick).

Install: copy `game/error_404/` into DDLC's `game/` folder (replace the old one). See `INSTALLATION.md`.
Quick test: in `error_404_p7_events.rpy` set `define e404_p7_test_start = True`, then press **Load Game** on the menu.
Static checks: `python tests/validate_v07.py` (the older `validate_project.py` only checks Prototypes 1-2 and now reports expected differences).

---
(older README follows)

# ERROR 404: MONIKA AWARENESS -- Prototype 2: THE TABLET (0.3.0)

Fan-made DDLC horror mod. Prototype 1 (Sayori "error 404", club glitch, Monika awareness, timeline skip) now continues into Prototype 2: Monika changes the background, something overrides her, and a tablet offers DELETE MONIKA / KEEP MONIKA with two different endings.

Start with `INSTALLATION.md`. Project map: `PROJECT_MEMORY.md`. Story: `STORY_CONTINUITY.md`. Test status: `TEST_REPORT.md`.

- `game/error_404/` the mod (6 `.rpy` files + generated assets)
- `backup_prototype_1/` the untouched Prototype 1 files (0.2.0) with hashes
- `tests/validate_project.py` static checks; `tests/test_checklist.md` manual checks
- `tools/generate_assets.py` regenerates every asset (no DDLC art or audio is included)

Honest status: statically validated only. Never run in Ren'Py/DDLC by me. Contains a photosensitivity-relevant rapid-change effect (see INSTALLATION.md options).
