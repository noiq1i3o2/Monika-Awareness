"""Generates the Prototype 3 assets (UI art + ambient audio). Deterministic.
Run from the project root:  python tools/generate_p3_assets.py
Requires Pillow + numpy. Nothing here uses DDLC art or audio."""
import os, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, "game", "error_404", "assets")
W, H = 1280, 720
MAGENTA, CYAN = (255, 90, 216), (0, 230, 255)
FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
         "C:/Windows/Fonts/consolab.ttf",
         "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf"]

def font(size):
    for p in FONTS:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default(size)

def save(img, rel):
    p = os.path.join(A, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, optimize=True)
    print("wrote", rel, os.path.getsize(p), "bytes")

# ---------------- tablet panel (880x470): clean bezel, calm screen ----------------
def tablet():
    S = 2  # draw at 2x, downsample for smooth edges
    w, h = 880 * S, 470 * S
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=30 * S, fill=(22, 22, 32, 255), outline=(78, 78, 110, 255), width=3 * S)
    ix0, iy0, ix1, iy1 = 20 * S, 20 * S, w - 20 * S, h - 20 * S
    d.rounded_rectangle([ix0, iy0, ix1, iy1], radius=14 * S, fill=(6, 6, 11, 255), outline=(40, 40, 62, 255), width=2 * S)
    # very faint scanlines (readability first)
    for y in range(iy0 + 4 * S, iy1 - 2 * S, 4 * S):
        d.line([(ix0 + 3 * S, y), (ix1 - 3 * S, y)], fill=(13, 13, 22, 255), width=S)
    # header rule + footer rule
    d.line([(60 * S, 98 * S), (w - 60 * S, 98 * S)], fill=MAGENTA + (150,), width=2 * S)
    d.line([(60 * S, h - 56 * S), (w - 60 * S, h - 56 * S)], fill=(60, 60, 90, 255), width=S)
    # corner brackets
    L, o = 30 * S, 34 * S
    for (cx, cy, sx, sy) in [(ix0 + o - 14 * S, iy0 + o - 14 * S, 1, 1), (ix1 - o + 14 * S, iy0 + o - 14 * S, -1, 1),
                             (ix0 + o - 14 * S, iy1 - o + 14 * S, 1, -1), (ix1 - o + 14 * S, iy1 - o + 14 * S, -1, -1)]:
        d.line([(cx, cy), (cx + sx * L, cy)], fill=CYAN + (200,), width=2 * S)
        d.line([(cx, cy), (cx, cy + sy * L)], fill=CYAN + (200,), width=2 * S)
    f = font(15 * S)
    d.text((92 * S, h - 46 * S), "TABLET // ID: ????", font=f, fill=(90, 90, 120, 255))
    d.text((w - 92 * S, h - 46 * S), "SRC: UNKNOWN", font=f, fill=(90, 90, 120, 255), anchor="ra")
    img = img.resize((880, 470), Image.LANCZOS)
    save(img, "tablet/e404_p2_tablet.png")

def info_card():
    """Compact status card (520x176) shown in the top-left corner: it must never cover
    Monika's face or the textbox."""
    S = 3
    w, h = 520 * S, 176 * S
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=16 * S, fill=(8, 8, 14, 225), outline=(78, 78, 110, 255), width=2 * S)
    for y in range(8 * S, h - 6 * S, 4 * S):
        d.line([(10 * S, y), (w - 10 * S, y)], fill=(14, 14, 24, 200), width=S)
    d.rectangle([0, 14 * S, 5 * S, h - 14 * S], fill=MAGENTA + (255,))
    save(img.resize((520, 176), Image.LANCZOS), "ui/e404_p3_card.png")

def button(name, accent, state):
    w, h = 620, 76
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if state == "idle":
        fill, line, bar = (14, 14, 24, 255), tuple(int(c * 0.55) for c in accent) + (255,), accent + (255,)
    elif state == "hover":
        fill, line, bar = (44, 16, 52, 255) if accent == MAGENTA else (10, 40, 52, 255), accent + (255,), accent + (255,)
    else:
        fill, line, bar = (10, 10, 16, 255), (44, 44, 58, 255), (60, 60, 78, 255)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=10, fill=fill, outline=line, width=2)
    d.rounded_rectangle([0, 0, 10, h - 1], radius=6, fill=bar)
    save(img, "ui/e404_p3_btn_%s_%s.png" % (name, state))

# ---------------- menu art ----------------
def menu_bg():
    yy, xx = np.mgrid[0:H, 0:W]
    r = np.sqrt(((xx - W * 0.62) / (W * 0.75)) ** 2 + ((yy - H * 0.5) / (H * 0.8)) ** 2)
    base = np.clip(26 - 30 * r, 3, 26)
    arr = np.zeros((H, W, 3), dtype=np.float32)
    arr[..., 0] = base * 0.9; arr[..., 1] = base * 0.55; arr[..., 2] = base * 1.4
    arr[(xx % 64 == 0) | (yy % 64 == 0)] += 3.0          # faint grid
    arr[(yy % 4) == 0] *= 0.8                             # scanlines
    save(Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)), "ui/e404_p3_menu_bg.png")

def vignette():
    yy, xx = np.mgrid[0:H, 0:W]
    r = np.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
    a = np.clip((r - 0.55) / 0.85, 0, 1) ** 1.6 * 235
    arr = np.zeros((H, W, 4), dtype=np.uint8)
    arr[..., 3] = a.astype(np.uint8)
    arr[..., 2] = 6
    save(Image.fromarray(arr, "RGBA"), "ui/e404_p3_vignette.png")

def static_noise():
    rs = np.random.RandomState(404)
    w, h = 340, 200   # shown at zoom 4 (blocky VHS noise); keeps the file tiny
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    m = rs.rand(h, w) > 0.93
    v = rs.randint(120, 255, (h, w))
    arr[..., 0] = v; arr[..., 1] = v; arr[..., 2] = v
    arr[..., 3] = np.where(m, rs.randint(20, 70, (h, w)), 0)
    arr[(np.arange(h) % 3) == 0, :, 3] //= 2
    save(Image.fromarray(arr, "RGBA"), "ui/e404_p3_static.png")

def sweat():
    S = 4
    w, h = 16 * S, 26 * S
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(w // 2, 1 * S), (2 * S, 15 * S), (w - 2 * S, 15 * S)], fill=(190, 225, 255, 215))
    d.ellipse([2 * S, 10 * S, w - 2 * S, 24 * S], fill=(190, 225, 255, 215))
    d.ellipse([5 * S, 14 * S, 8 * S, 19 * S], fill=(255, 255, 255, 190))
    save(img.resize((16, 26), Image.LANCZOS), "ui/e404_p3_sweat.png")

# ---------------- audio ----------------
def wav(name, sr, sig, gain):
    sig = np.clip(sig * gain, -1, 1)
    p = os.path.join(A, "audio", name)
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((sig * 32767).astype("<i2").tobytes())
    print("wrote audio/" + name, os.path.getsize(p), "bytes")

def bandpass(x, sr, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1.0 / sr)
    X[(f < lo) | (f > hi)] = 0
    return np.fft.irfft(X, len(x))

def audio():
    rs = np.random.RandomState(7)
    # drone: seamless 6 s loop (every frequency completes a whole number of cycles)
    sr, secs = 11025, 6
    t = np.arange(sr * secs) / float(sr)
    sig = (np.sin(2 * np.pi * 55 * t) * 0.5 + np.sin(2 * np.pi * (55 + 1 / 6.0 * 5) * t) * 0.4
           + np.sin(2 * np.pi * 82.5 * t) * 0.18 + np.sin(2 * np.pi * 164 * t) * 0.05)
    sig *= 0.75 + 0.25 * np.sin(2 * np.pi * (1 / 6.0) * t)
    n = bandpass(rs.uniform(-1, 1, len(t)), sr, 60, 400)
    n *= 0.5 + 0.5 * np.sin(2 * np.pi * (2 / 6.0) * t + 1)
    wav("e404_p3_drone.wav", sr, sig * 0.8 + n * 0.25, 0.42)
    # heartbeat: two thumps
    sr = 22050
    t = np.arange(int(sr * 1.3)) / float(sr)
    hb = np.zeros_like(t)
    for st, amp in ((0.0, 1.0), (0.24, 0.7)):
        tt = np.clip(t - st, 0, None)
        hb += amp * np.sin(2 * np.pi * (58 - 18 * tt) * tt) * np.exp(-tt * 14) * (t >= st)
    wav("e404_p3_heartbeat.wav", sr, hb, 0.9)
    # static burst
    t = np.arange(int(sr * 0.9)) / float(sr)
    s = rs.uniform(-1, 1, len(t)) * np.exp(-t * 5)
    s *= (np.sin(2 * np.pi * 37 * t) > -0.3)
    wav("e404_p3_static.wav", sr, s, 0.55)
    # whisper: band-limited noise shaped like syllables
    t = np.arange(int(sr * 2.4)) / float(sr)
    env = np.zeros_like(t)
    for c, wd in ((0.2, 0.12), (0.45, 0.1), (0.7, 0.16), (1.05, 0.1), (1.3, 0.14), (1.65, 0.2)):
        env += np.exp(-((t - c) / wd) ** 2)
    wsp = bandpass(rs.uniform(-1, 1, len(t)), sr, 1800, 5200) * env
    wsp *= np.linspace(1, 0.4, len(t))
    wav("e404_p3_whisper.wav", sr, wsp, 0.8)

if __name__ == "__main__":
    info_card()
    for nm, col in (("m", MAGENTA), ("c", CYAN)):
        for st in ("idle", "hover", "dis"):
            button(nm, col, st)
    sweat(); vignette(); static_noise(); audio()
