"""Generates every original asset for ERROR 404: MONIKA AWARENESS.
Run from the project root:  python tools/generate_assets.py
Requires Pillow + numpy. Nothing here uses DDLC art or audio."""
import os, wave, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, "game", "error_404", "assets")
W, H = 1280, 720
NEAR_BLACK, MAGENTA, CYAN, WHITE = (8, 8, 14), (255, 0, 200), (0, 230, 255), (240, 240, 245)
FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
         "C:/Windows/Fonts/consolab.ttf",
         "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf"]

def font(size):
    for p in FONTS:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default(size)

def pixelate(img, factor):
    small = img.resize((img.width // factor, img.height // factor), Image.NEAREST)
    return small.resize(img.size, Image.NEAREST)

def channel_split(img, dx):
    r, g, b = img.split()[:3]
    r = Image.fromarray(np.roll(np.array(r), -dx, axis=1))
    b = Image.fromarray(np.roll(np.array(b), dx, axis=1))
    return Image.merge("RGB", (r, g, b))

def slice_shift(img, rng, bands, maxshift):
    arr = np.array(img)
    for _ in range(bands):
        y = rng.randrange(0, H - 30)
        h = rng.randrange(4, 28)
        arr[y:y + h] = np.roll(arr[y:y + h], rng.randrange(-maxshift, maxshift), axis=1)
    return Image.fromarray(arr)

def scanlines(img, alpha=40):
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    for y in range(0, img.height, 4):
        d.line([(0, y), (img.width, y)], fill=(0, 0, 0, alpha))
    return Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")

def save(img, rel):
    p = os.path.join(A, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, optimize=True)
    print("wrote", rel, os.path.getsize(p), "bytes")

def card(seed, big, lines, accent):
    rng = random.Random(seed)
    img = Image.new("RGB", (W, H), NEAR_BLACK)
    d = ImageDraw.Draw(img)
    for _ in range(18):
        x, y = rng.randrange(0, W, 16), rng.randrange(0, H, 16)
        d.rectangle([x, y, x + rng.choice([16, 32, 64]), y + 16], fill=(20, 20, 32))
    d.text((90, 210), big, font=font(150), fill=WHITE)
    y = 410
    for ln in lines:
        d.text((96, y), ln, font=font(34), fill=accent)
        y += 52
    d.rectangle([96, 600, 96 + 700, 616], outline=accent, width=2)
    d.rectangle([98, 602, 98 + rng.randrange(120, 520), 614], fill=accent)
    img = pixelate(img, 2)
    img = slice_shift(img, rng, 7, 70)
    img = channel_split(img, 9)
    return scanlines(img)

def gradient(top, bot):
    arr = np.zeros((H, W, 3), dtype=np.uint8)
    for y in range(H):
        t = y / float(H)
        arr[y, :] = [int(top[i] * (1 - t) + bot[i] * t) for i in range(3)]
    return Image.fromarray(arr)

def write_wav(name, secs, bursts, gain):
    sr = 22050
    n = int(sr * secs)
    rs = np.random.RandomState(404)
    sig = np.zeros(n)
    for start, dur, step in bursts:
        s, e = int(start * sr), int((start + dur) * sr)
        noise = rs.uniform(-1, 1, e - s)
        noise = np.repeat(noise[::step], step)[: e - s]
        sig[s:e] += noise * np.linspace(1, 0, e - s)
    sig = np.clip(sig * gain, -1, 1)
    p = os.path.join(A, "audio", name)
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((sig * 32767).astype("<i2").tobytes())
    print("wrote audio/" + name, os.path.getsize(p), "bytes")

def main():
    rng = random.Random(404)
    t = Image.new("RGB", (W, H), NEAR_BLACK)
    d = ImageDraw.Draw(t)
    d.text((W // 2, 250), "ERROR 404", font=font(120), fill=WHITE, anchor="mm")
    d.text((W // 2, 380), "M O N I K A   A W A R E N E S S", font=font(46), fill=CYAN, anchor="mm")
    d.text((W // 2, 470), "fan-made prototype  //  not affiliated with Team Salvato", font=font(22), fill=(150, 150, 170), anchor="mm")
    t = channel_split(slice_shift(pixelate(t, 2), rng, 5, 40), 7)
    save(scanlines(t), "title/e404_title.png")

    rng = random.Random(1)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    for _ in range(26):
        y = rng.randrange(0, H - 30); h = rng.randrange(3, 26)
        x = rng.randrange(0, W - 700); w = rng.randrange(120, 600)
        d.rectangle([x, y, x + w, y + h], fill=rng.choice([MAGENTA, CYAN, WHITE]) + (rng.randrange(40, 110),))
    for y in range(0, H, 4):
        d.line([(0, y), (W, y)], fill=(0, 0, 0, 45))
    save(ov, "glitch/e404_glitch_overlay.png")

    save(card(11, "SAYORI", ["event_01  ::  SKIPPED", "dialogue  ::  [MISSING]", "timeline  ::  +1 day"], MAGENTA), "montage/e404_card_sayori.png")
    save(card(22, "YURI", ["event_02  ::  SKIPPED", "dialogue  ::  [MISSING]", "timeline  ::  +1 day"], CYAN), "montage/e404_card_yuri.png")
    save(card(33, "NATSUKI", ["event_03  ::  SKIPPED", "dialogue  ::  [MISSING]", "timeline  ::  +1 day"], MAGENTA), "montage/e404_card_natsuki.png")
    save(card(44, "MONIKA", ["event_04  ::  ??????", "dialogue  ::  [WHO IS RUNNING THIS]", "timeline  ::  end of file"], CYAN), "montage/e404_card_monika.png")

    rng = random.Random(99)
    f = Image.new("RGB", (W, H), (3, 3, 6))
    d = ImageDraw.Draw(f)
    d.text((W // 2, 300), "end of prototype", font=font(44), fill=(120, 120, 140), anchor="mm")
    d.text((W // 2, 380), "signal source :: unknown", font=font(34), fill=CYAN, anchor="mm")
    f = channel_split(slice_shift(pixelate(f, 2), rng, 3, 30), 5)
    save(scanlines(f, 30), "glitch/e404_final_overlay.png")

    bg = gradient((24, 18, 40), (6, 6, 12)); d = ImageDraw.Draw(bg)
    for x in range(120, W - 140, 240):
        d.rectangle([x, 120, x + 140, 300], outline=(60, 60, 90), width=3)
    save(bg, "bg/e404_bg_club_fallback.png")
    bg = gradient((40, 30, 60), (10, 10, 20)); d = ImageDraw.Draw(bg)
    d.rectangle([0, 520, W, H], fill=(14, 14, 24))
    save(bg, "bg/e404_bg_street_fallback.png")

    write_wav("e404_glitch.wav", 0.7, [(0.0, 0.12, 6), (0.22, 0.08, 14), (0.38, 0.25, 3)], 0.45)
    write_wav("e404_blip.wav", 0.25, [(0.0, 0.2, 9)], 0.3)

def main_p2():
    """Prototype 2 assets (additive: nothing from Prototype 1 is regenerated differently)."""
    # four distinct fallback backgrounds so forced changes are visible even without DDLC art
    specs = [("a", (30, 24, 52), (8, 8, 16), "windows"),
             ("b", (18, 38, 48), (6, 10, 14), "stripes"),
             ("c", (52, 24, 36), (14, 6, 10), "boxes"),
             ("d", (34, 34, 40), (10, 10, 12), "door")]
    for key, top, bot, kind in specs:
        bg = gradient(top, bot); d = ImageDraw.Draw(bg)
        if kind == "windows":
            for x in range(100, W - 140, 260): d.rectangle([x, 90, x + 170, 330], outline=(80, 80, 120), width=4)
        elif kind == "stripes":
            for x in range(0, W, 80): d.rectangle([x, 0, x + 18, H], fill=(24, 54, 66))
        elif kind == "boxes":
            for i in range(6): d.rectangle([140 + i * 170, 200 + (i % 2) * 90, 260 + i * 170, 420 + (i % 2) * 90], outline=(110, 50, 70), width=4)
        else:
            d.rectangle([520, 140, 760, 560], outline=(90, 90, 100), width=6); d.ellipse([720, 340, 740, 360], fill=(120, 120, 130))
        d.rectangle([0, 560, W, H], fill=(10, 10, 14))
        save(bg, "bg/e404_bg_p2_%s.png" % key)

    # tablet: simple dark rectangle with bezel, no text (text is drawn by the screen so it stays crisp)
    TW, TH = 880, 470
    rng = random.Random(2)
    t = Image.new("RGBA", (TW, TH), (0, 0, 0, 0)); d = ImageDraw.Draw(t)
    d.rounded_rectangle([0, 0, TW - 1, TH - 1], radius=26, fill=(34, 34, 44, 255), outline=(120, 120, 140, 255), width=4)
    d.rounded_rectangle([22, 22, TW - 23, TH - 23], radius=14, fill=(6, 6, 12, 245), outline=(60, 60, 80, 255), width=2)
    for _ in range(9):
        y = rng.randrange(40, TH - 60); x = rng.randrange(40, TW - 300)
        d.rectangle([x, y, x + rng.randrange(80, 260), y + rng.randrange(3, 9)], fill=rng.choice([MAGENTA, CYAN]) + (70,))
    for y in range(26, TH - 26, 4): d.line([(26, y), (TW - 26, y)], fill=(0, 0, 0, 60))
    save(t, "tablet/e404_p2_tablet.png")

    # dim overlay used for the "familiar but wrong" background
    dim = Image.new("RGBA", (W, H), (6, 6, 22, 120)); d = ImageDraw.Draw(dim)
    for y in range(0, H, 4): d.line([(0, y), (W, y)], fill=(0, 0, 0, 40))
    save(dim, "glitch/e404_p2_dim.png")

    # ending cards
    rng = random.Random(7)
    a = Image.new("RGB", (W, H), (3, 3, 6)); d = ImageDraw.Draw(a)
    d.text((W // 2, 300), "ERROR 404", font=font(96), fill=WHITE, anchor="mm")
    d.text((W // 2, 410), "DELETION COULD NOT BE VERIFIED", font=font(40), fill=MAGENTA, anchor="mm")
    a = channel_split(slice_shift(pixelate(a, 2), rng, 4, 36), 6)
    save(scanlines(a, 34), "ending/e404_p2_end_a.png")
    b = Image.new("RGB", (W, H), (3, 3, 6)); d = ImageDraw.Draw(b)
    d.text((W // 2, 280), "SUBJECT RETAINED", font=font(56), fill=WHITE, anchor="mm")
    d.text((W // 2, 370), "SECONDARY PROCESS DETECTED", font=font(40), fill=CYAN, anchor="mm")
    d.text((W // 2, 440), "SOURCE: UNKNOWN", font=font(34), fill=(120, 120, 140), anchor="mm")
    b = channel_split(slice_shift(pixelate(b, 2), rng, 4, 36), 6)
    save(scanlines(b, 34), "ending/e404_p2_end_b.png")

    write_wav("e404_p2_tick.wav", 0.08, [(0.0, 0.07, 5)], 0.35)
    # alert: low tone + crushed noise
    sr = 22050; n = int(sr * 0.7); tt = np.arange(n) / float(sr)
    sig = 0.35 * np.sin(2 * np.pi * 98 * tt) * np.linspace(1, 0, n)
    rs = np.random.RandomState(9); nz = np.repeat(rs.uniform(-1, 1, n // 7 + 1), 7)[:n]
    sig = np.clip(sig + 0.25 * nz * np.linspace(1, 0, n) ** 2, -1, 1)
    with wave.open(os.path.join(A, "audio", "e404_p2_alert.wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((sig * 32767).astype("<i2").tobytes())
    print("wrote audio/e404_p2_alert.wav")

if __name__ == "__main__":
    main()
    main_p2()
