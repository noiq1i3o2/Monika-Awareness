"""Generates the v0.7 walk assets (darkness mask, lamp glow, joystick). Needs Pillow.
Usage: python tools/generate_p7_assets.py   (deterministic, no DDLC art involved)"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "game", "error_404", "assets", "p7")
os.makedirs(OUT, exist_ok=True)

def radial(size):
    """0 at the centre -> 255 at the edge of the circle (clipped beyond)."""
    return Image.radial_gradient("L").resize((size, size), Image.BICUBIC)

# 1) darkness: a small pool of light around the player (screen centre), black outside.
W, H, R = 1280, 720, 330
g = radial(2 * R)
def dark_curve(v):
    t = max(0.0, (v / 255.0 - 0.30) / 0.70)      # clear core, then falls off
    return int(min(1.0, t ** 0.85) * 246)
a = g.point(dark_curve)
dark = Image.new("RGBA", (W, H), (2, 2, 6, 246))
layer = Image.new("RGBA", (2 * R, 2 * R), (2, 2, 6, 255))
layer.putalpha(a)
dark.paste(Image.new("RGBA", (2 * R, 2 * R), (0, 0, 0, 0)), (W // 2 - R, H // 2 - R))
dark.paste(layer, (W // 2 - R, H // 2 - R))
dark.save(os.path.join(OUT, "e404_p7_dark.png"))

# 2) warm lamp glow (256x256)
gl = radial(256)
ga = gl.point(lambda v: int(max(0.0, 1.0 - v / 255.0) ** 1.8 * 150))
glow = Image.new("RGBA", (256, 256), (255, 205, 130, 255))
glow.putalpha(ga)
glow.save(os.path.join(OUT, "e404_p7_glow.png"))

# 3) joystick (supersampled for smooth edges)
def circle_img(size, fill, outline=None, width=0):
    s = 4
    im = Image.new("RGBA", (size * s, size * s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((2, 2, size * s - 3, size * s - 3), fill=fill, outline=outline, width=width * s)
    return im.resize((size, size), Image.LANCZOS)
circle_img(200, (120, 200, 255, 28), (150, 215, 255, 120), 3).save(os.path.join(OUT, "e404_p7_joy_base.png"))
circle_img(84, (170, 225, 255, 120), (210, 240, 255, 170), 2).save(os.path.join(OUT, "e404_p7_joy_knob.png"))
print("wrote", sorted(os.listdir(OUT)))
