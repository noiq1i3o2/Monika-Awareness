# Installation -- Prototype 2: THE TABLET (DDLC, Ren'Py 6.99)

Prototype 2 is an update of the same mod. It is installed exactly like Prototype 1: plain `.rpy` files in `game/error_404/`. It is a standalone DDLC story mod, not a Monika After Story submod.

1. **Back up.** Copy your whole DDLC folder (or at least your current `game/error_404/` folder). Mod a copy, never your only install.
2. Use `E404_P2_INSTALL.zip` (contains only `game/error_404/`). Extract it into your DDLC folder (the one that contains `game/`), **replacing** the existing `game/error_404/` files. Final layout: `game/error_404/error_404_p2_labels.rpy`.
   - Prototype 1 files keep their names, so they are overwritten in place. Anything you want to keep is in `backup_prototype_1/` of the full project.
3. If a `game/error_404/*.rpyc` file exists from an earlier run, delete it (Ren'Py will rebuild it).
4. Launch DDLC (Windows: `DDLC.exe`; phone launcher: choose the **Ren'Py 6.99** runtime) and press **New Game**. Enter any name when DDLC asks (that prompt always comes first).
5. Play through Prototype 1. Right after Monika says "Now you're all mine." Prototype 2 begins.

## How to tell it loaded
- `log.txt` or console shows `[E404] ERROR 404: MONIKA AWARENESS 0.3.0 (Prototype 2) loaded` and `[E404] hook OK`.
- After Monika's last Prototype 1 line you see her change the background, then it starts changing by itself.

## Options (edit `game/error_404/error_404_p2_events.rpy`)
- `define e404_prototype2_enabled = False` : stop after Prototype 1 (original ending card).
- `define e404_p2_reduce_flashing = True` : slower background changes, no glitch flash (photosensitivity).

## Endings and returning
Both endings end with `return`, which goes to the main menu. Press **New Game** to play again. Endings are recorded as `persistent.e404_p2_ending` ("A" or "B"). No saves, files or assets are deleted or changed.

## Troubleshooting
- Normal DDLC intro, no `[E404]` line: `error_404` is in the wrong place (it must be `game/error_404/`) or the launcher runs another game folder.
- `hook FAILED` in the log: see `patches/README.md` (manual one-line route).
- Prototype 1 plays but ends on "end of prototype": `e404_prototype2_enabled` is False or the new `error_404_labels.rpy` was not copied.
- Error screen: send the text or `traceback.txt`.
- Plain dark/gradient backgrounds instead of DDLC art: the guessed DDLC background names were not found; the mod fell back to its own art. Everything still works.
- Undo: delete `game/error_404/` and restore your backup.


## v0.7 (THE ZERO)
1. Delete the old `game/error_404/` folder in DDLC, then copy this `game/error_404/` in. (Do not merge old and new.)
2. Play through to the void menu as before. Each time you press LOAD GAME the "save_01.sav" size drops; after the third visit it reads **0 KB**.
3. Press LOAD GAME again: the error box appears.
   - **Go Back -> Yes**: resets this mod's own progress flags only and restarts the game. **No** returns to the error box. Nothing outside the mod (real saves, backups, DDLC files) is deleted.
   - **Continue Anyway**: glitched Sayori, Yuri, Natsuki, then the walk home.
4. To jump straight to it: set `define e404_p7_test_start = True` in `error_404_p7_events.rpy` and press LOAD GAME.

Options (all in `error_404_p7_events.rpy`): `e404_p7_punish_wrong_device` (wrong device = inverted controls + renamed window title), `e404_p7_creep_after` (seconds before the figure approaches on its own), `e404_p7_calm` (no static/flashes), the three `e404_p7_line_*` character lines (edit to match your copy of DDLC).

Walk controls: PC = W A S D or arrow keys. Mobile = press and drag on the screen (floating joystick). Both always work, whichever device you pick.
